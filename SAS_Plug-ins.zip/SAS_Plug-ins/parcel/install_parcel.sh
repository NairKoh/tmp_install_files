#!/bin/bash
SRCDIR=`pwd`
# check for mandatory argumental options
if [ $# -lt 1 ]; then
  echo "Option: -v <Linux distro>"
  echo "Specify the Linux distro for your Cloudera Hadoop cluster."
  echo "Choose one of the Linux versions redhat5, redhat6, redhat7, suse11x, ubuntu10, ubuntu12, ubuntu14, debian6, debian7."
  echo "Redhat includes Redhat Linux and clones such as CentOS and Scientific Linux."
  echo "Example"
  echo "install_parcel.sh -v debian6"
  exit 1
fi

# parse the options
while getopts 'v:' opt ; do
  case $opt in
    v) DISTRO=$OPTARG ;;
  esac
done

sudo -n true
if [ $? -ne 0 ]
   then
   echo "You do not have a root privilege to execute this script. Rerun the script with a root or password-less sudo account."
   exit 1
fi

if [ ! -d $SRCDIR ]
then
  echo "Specify the full path of the source location where the parcel files exist."
  exit 1
else
  echo $SRCDIR
fi

if [ ! $DISTRO ]
then
  echo "Specify the Linux distro for your Cloudera cluster with -v option."
  echo "Choose one of the Linux versions redhat5, redhat6, redhat7, suse11x, ubuntu10, ubuntu12, ubuntu14, debian6, debian7."
  echo "Redhat includes Redhat Linux and clones such as CentOS and Scientific Linux."
  exit 1
fi

TARGETDIR=/usr/cloudera/parcel-repo

case $DISTRO in
(redhat5)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-el5.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-el5.parcel.sha
;;
(redhat6)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-el6.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha
;;
(redhat7)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-el7.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-el7.parcel.sha
;;
(suse11x)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-sles11.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-sles11.parcel.sha
;;
(ubuntu10)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-lucid.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-lucid.parcel.sha
;;
(ubuntu12)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-precise.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-precise.parcel.sha
;;
(ubuntu14)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-trusty.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-trusty.parcel.sha
;;
(debian6)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-squeeze.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-squeeze.parcel.sha
;;
(debian7)
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel $TARGETDIR/SASHDAT-03.04.02.p0.1-wheezy.parcel
sudo cp $SRCDIR/SASHDAT-03.04.02.p0.1-el6.parcel.sha $TARGETDIR/SASHDAT-03.04.02.p0.1-wheezy.parcel.sha
;;
esac
sudo chown cloudera-scm:cloudera-scm /usr/cloudera/parcel-repo/SASHDAT-03.04.02.p0.1*
echo "To complete the install process, the Cloudera Manager Server needs to be restarted." 
echo "Press y if you want the script to restart or n if you want to restart manually later."
read response
if [[ $response == "y" || $response == "Y" ]]
then
	sudo service cloudera-scm-server restart
        echo "Waiting..."
        sleep 60
	echo "You can now distribute SAS HDATPlugins parcel from the Cloudera Manager."
else
	echo "Skipped restarting the Cloudera Manager Server."
fi
exit 0