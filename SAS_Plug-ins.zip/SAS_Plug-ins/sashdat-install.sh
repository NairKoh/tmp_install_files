#!/bin/bash
# Copyright 2017 SAS Institute Inc.
# SAS Campus Drive, Cary, North Carolina 27513, USA.
# All rights reserved.
#
# License: This script and its contents is property of SAS Institute and
# is to be used in conjunction with SAS software and tools only. You may not
# copy, modify, or redistribute, in whole or in part, any portion of this
# script without expressed written permission from SAS Institute.
#
##H=======================================
##HSAS HDAT Plugins for Hadoop
##H=======================================
##HAction options syntax:
##H
##H sashdat-install.sh [-x] -add [-host <HostNames> | -hostfile <FileName>]
##H
##H                    [-x] -remove [-host <HostNames> | -hostfile <FileName>]
##H
##H
##H -add       : Installs SAS HDAT Plugins on the provided list of hosts. If the list of hosts is not provided, the script retrieves the list
##H              of data nodes from the Hadoop cluster configuration.
##H
##H -host      : A host or a list of hosts, separated by spaces or commas. Options -hostfile and -host are mutually exclusive.
##H              For example: -host "server1 server2 server3" or -host server1 or "host1, host2, host3, host4"
##H
##H -hostfile  : The full path to a file containing a list of hosts. Options -hostfile and -host are mutually exclusive.
##H
##H -hdfsuser  : user-ID specifies the user ID that has an execution right for the hdfs command. 
##H              The command 'hdfs dfsadmin -report' is run by the script to retrieve the nodes of the Hadoop cluster when the script is 
##H              launched without an option -host or -hostfile. Default: hdfs.
##H
##H -remove    : Removes SAS HDAT Plugins from the provided host or list of hosts. If the list of hosts is not provided, the script retrieves the
##H              list of data nodes from the Hadoop cluster configuration.
##H
##H -x         : Runs the script solely under the current user's credentials. When running in conjunction with -add, -check, and -remove options, a list of hosts
##H              must be provided. When used, this option must be the first argument passed to the script.
##H
##H -hdathome  : Installs SAS HDAT Plugins with this file system. Default: /opt/sas/<HDATHome>/   
##H
##H
##HInformational options syntax:
##H
##H sashdat-install.sh [-x] -check  [-host <HostNames> | -hostfile <FileName>] [-hdfsuser <UserID>]
##H                -env
##H                -nodelist
##H                -version
##H
##HWhere:
##H
##H -check     : Checks whether SAS HDAT Plugins is installed under the current install folder on remote hosts.
##H
##H -env       : Displays the environment variables that SAS HDAT Plugins install script uses.
##H
##H -nodelist  : Displays all live data nodes of the cluster. This option requires sudo privileges and hdfs execution right.
##H
##H -version   : Displays the version of SAS HDAT Plugins that the script is about to install.
##H
##H

##XEND
#==========================================================
black='\033[0;30m'
darkgray='\033[1;30m'
blue='\033[0;34m'
lightblue='\033[1;34m'
green='\033[0;32m'
lightgreen='\033[1;32m'
cyan='\033[0;36m'
lightcyan='\033[1;36m'
red='\033[0;31m'
lightred='\033[1;31m'
purple='\033[0;35m'
lightpurple='\033[1;35m'
brownorange='\033[0;33m'
yellow='\033[1;33m'
lightgray='\033[0;37m'
white='\033[1;37m'
nocolor='\033[0m'
dcolor=${nocolor}
icolor=${nocolor}
ecolor=${red}
wcolor=${yellow}
#==========================================================
THIS_PROGRAM=$0
INSTALL_COMMAND_PATH=`dirname $0`
INSTALL_RUN_DIR=$INSTALL_COMMAND_PATH
LOG_FILE=/tmp/sashdat-install.log
#==========================================================
LOCAL_HOST_FULLNAME=`hostname`
LOCAL_HOST=${LOCAL_HOST_FULLNAME%%.*}
#==========================================================
USER_LOCAL_DIR=`pwd`
cd $INSTALL_COMMAND_PATH
HDAT_BIN=`pwd`
HDAT_BASE_DIR=/opt/sas
HDAT_HOME_DIR=$HDAT_BASE_DIR/HDATHome
HDAT_LIB_DIR=$HDAT_HOME_DIR/lib
HDAT_BIN_DIR=$HDAT_HOME_DIR/bin
HDAT_JAR_FILENAME=sas.cas.hadoop.jar
LASR_JAR_FILENAME=sas.lasr.hadoop.jar
HDAT_BIN_FILENAME=sascasfd
LASR_BIN_FILENAME=saslasrfd
#==========================================================
cd $USER_LOCAL_DIR
#==========================================================
SSH_OPTIONS="-x -q -o StrictHostKeyChecking=no -o PasswordAuthentication=no -o UserKnownHostsFile=/dev/null"
SCP_OPTIONS="-q -o StrictHostKeyChecking=no -o PasswordAuthentication=no -o UserKnownHostsFile=/dev/null"
MYPID=$$
#==========================================================
let IS_LINK_HADOOP_LIB=0
let IS_FORCE_OVERWRITE=0
let IS_HOSTOPTION=0
#==========================================================
HDAT_PRODUCT_VERSION=03.04.02 
HDAT_TAR_FILE=sashdat-$HDAT_PRODUCT_VERSION
# Maximum number of parallel copies between master and slaves
MAX_PARALLEL_SCP=10
## ===============================================================
## How are we going to su
## ===============================================================
RUNUSER="sudo su -s /bin/bash -l "
#==========================================================
# The call to this function removes leading and trailing
# spaces
#==========================================================
trimSpaces()
{
  echo -e "$*"
}
#==========================================================
# The call to this function replaces spaces by a back
# slash (\ ) followed by a space.
#==========================================================
replaceSpaces()
{
  echo -e $*| awk '{str=$0; gsub(/ /, "\\ ", str); print str}'
}
#==========================================================
# The call to this function replaces commas by spaces
#==========================================================
replaceCommasBySpaces()
{
  echo -e $*| awk '{str=$0; gsub(/,/, " ", str); print str}'
}
#==========================================================
# Display the help information that is in the top of the
# file.
printSyntax()
{
  THIS_FILE=${1}

  while read record; do
    head=`echo -e "$record" | cut -c1-3`

    if [ "$head" = "##H" ]; then
        echo -e "$record" | cut -c4-
    elif [ "$head" = "##X" ]; then
        exit -1
    fi
  done < $THIS_FILE

  exit -1
}
## ===============================================================
# Validate a directory location
#
validateDirectoryLocation()
{
  dirName=$1

  if [ ! -e $dirName ]; then
    echo -e "Directory $dirName does not exist."
    return
  fi

  if [ ! -d $dirName ]; then
    echo -e "The name $dirName is not a directory."
    return
  fi

  #if [ ! -w $dirName ]; then
  #  echo -e "Directory $dirName does not have write permission."
  #  return
  #fi
}
## ===============================================================
# Validate a file location
#
validateFileLocation()
{
  fileName=$1

  if [ ! -e $fileName ]; then
    echo -e "File $fileName does not exist."
    return
  fi

  if [ ! -f $fileName ]; then
    echo -e "The name $fileName is not a supported file."
    return
  fi

  if [ ! -r $fileName ]; then
    echo -e "File $fileName does not have read permission."
    return
  fi
}

#==========================================================
# Check to see if Apache HAdoop cluster
#==========================================================
isApacheCluster()
{
  HDFS_COMMAND="hdfs version | grep apache"
  let rc=$?

  if [ $rc -eq 0 ]; then
    HADOOP_DISTRO = "APACHE"
  fi
}

#==========================================================
# Get Hadoop version
#==========================================================
setSpecificVersionCommands()
{
  HADOOP_CMD_RM="-rm"
  HADOOP_CMD_RMR="-rm -r"
  HADOOP_CMD_MKDIR="-mkdir -p"
}

#==========================================================
# Show Hadoop home
#==========================================================
showHadoopHome()
{
 CUR_HADOOP_HOME=`sudo readlink -f $(type -P hadoop) | awk '1' RS="/bin/hadoop"`
 echo "    " >>  ${LOG_FILE}

 if [ "$CUR_HADOOP_HOME" == "" ] || [ "$CUR_HADOOP_HOME" == "/usr" ]; then
   echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Verify that the environment variable HADOOP_HOME is set and HADOOP_HOME/bin is added to the PATH."  2>&1 | tee -a ${LOG_FILE}
   exit
 fi

 echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} The script detects that the environment variable HADOOP_HOME is set to $CUR_HADOOP_HOME."  2>&1 | tee -a ${LOG_FILE}
 echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Retry after resetting the HADOOP_HOME variable if you want to use a different HADOOP_HOME."  2>&1 | tee -a ${LOG_FILE}

 promptYesNo "--> Enter Yes(y) to continue with the current HADOOP_HOME setting or No(n) to terminate. [y/n]? " Y N

 if [ "$userInput" == "N" ]; then
   echo "    "
   echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} SAS HDAT install was canceled."  2>&1 | tee -a ${LOG_FILE}
   echo "    "
   exit 1
 fi

# promptYesNo1
}

#==========================================================
# Get a list of LIVE nodes installed on the cluster
#==========================================================
getNodesList()
{
  HDFS_COMMAND="hdfs dfsadmin -report | grep Hostname | awk '{print $2}'"
  $RUNUSER $HDFS_USER -c "${HDFS_COMMAND} " 2>&1

  #----------------------------------------------------------
  if [ $IS_NOSUDO -eq 1 ]; then
    echo "Automatic detection of a cluster topology is not available when running the install script with -x option."  2>&1 | tee -a ${LOG_FILE}
    return 1
  fi

  let rc=$?

  if [ $rc -ne 0 ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Verify that the top folders of the install location have read and execute permissions."  2>&1 | tee -a ${LOG_FILE}
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Verify that the user $HDFS_USER is a Hadoop superuser."  2>&1 | tee -a ${LOG_FILE}
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} If you do not have sudo privileges, run the script with -x option."  2>&1 | tee -a ${LOG_FILE}
  fi
  return $rc
}
#==========================================================
# Dump environment
#==========================================================
dumpEnvironment()
{
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} HDAT_BIN_DIR=$HDAT_BIN_DIR"  2>&1 | tee -a ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} HDAT_LIB_DIR=$HDAT_LIB_DIR" 2>&1 | tee -a ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} HDAT_HOME_DIR=$HDAT_HOME_DIR" 2>&1 | tee -a ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} INSTALL_RUN_DIR=$INSTALL_RUN_DIR" 2>&1 | tee -a ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} HDAT_PRODUCT_VERSION=$HDAT_PRODUCT_VERSION" 2>&1 | tee -a ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} HDAT_TAR_FILE=$HDAT_TAR_FILE" 2>&1 | tee -a ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} HDFS_USER=$HDFS_USER"  2>&1 | tee -a ${LOG_FILE}
#  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} JAVA_HOME=$HDAT_JAVA_HOME" 2>&1 | ${LOG_FILE}
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} USER_LOCAL_DIR=$USER_LOCAL_DIR" 2>&1 | tee -a ${LOG_FILE}
  echo "   " >> ${LOG_FILE}
}
#==========================================================
# Make sure the local host is in the list of nodes.
#==========================================================
checkNodesList()
{
  LOCALHOST=`hostname`

  for node in $HDAT_PLUGINS_HOSTLIST; do
    if [ $node != "Hostname:" ]; then
        if [ "${node%%.*}" == "${LOCALHOST%%.*}" ]; then
          isHostFound=1;
        fi
    fi
  done

  if [ ! $isHostFound ]; then
    HDAT_PLUGINS_HOSTLIST="$HDAT_PLUGINS_HOSTLIST $LOCALHOST"
  fi
}
#================================================================
# Verify that the HDAT is already installed in the current location
#================================================================
checkHDATInstallLocation()
{
  let indx=-1;
  let count=0;
  let serverCount=0;

  if [ "$LOCAL_HOST" == "$REMOTE_HOST" ] ; then
    if [ "$ACTION" == "CHECK" ]; then
        if [ -e $HDAT_LIB_DIR/${HDAT_JAR_FILENAME} ] || [ -e $HDAT_BIN_DIR/${HDAT_BIN_FILENAME} ]; then
          echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO: ${green}Found ${nocolor}SAS HDAT Plugins installed." 2>&1 | tee -a ${LOG_FILE}
          exit 1
        fi

        # CLoudera
        if [ -e $CUR_HADOOP_HOME/lib/hadoop/lib/${HDAT_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/lib/hadoop/bin/${HDAT_BIN_FILENAME} ]; then
          echo -e `date` "$LOCAL_HOST_FULLNAME ${wcolor}WARN: ${red}Found ${nocolor}Previous version of SAS HDAT Plugins installed."  2>&1 | tee -a ${LOG_FILE}
          exit 1
        fi

        if [ -e $CUR_HADOOP_HOME/lib/hadoop/lib/${LASR_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/lib/hadoop/bin/${LASR_BIN_FILENAME} ]; then
          echo -e `date` "$LOCAL_HOST_FULLNAME ${wcolor}WARN: ${red}Found ${nocolor}SAS 9.4 version of SAS HDAT Plugins installed."  2>&1 | tee -a ${LOG_FILE}
          exit 1
        fi

        # Hortonworks
        if [ -e $CUR_HADOOP_HOME/lib/${HDAT_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/bin/${HDAT_BIN_FILENAME} ]; then
          echo -e `date` "$LOCAL_HOST_FULLNAME ${wcolor}WARN: ${red}Found ${nocolor}Previous version of SAS HDAT Plugins installed."  2>&1 | tee -a ${LOG_FILE}
          exit 1
        fi

        if [ -e $CUR_HADOOP_HOME/lib/${LASR_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/bin/${LASR_BIN_FILENAME} ]; then
          echo -e `date` "$LOCAL_HOST_FULLNAME ${wcolor}WARN: ${red}Found ${nocolor}SAS 9.4 version of SAS HDAT Plugins installed." 2>&1 | tee -a ${LOG_FILE}
          exit 1
        fi
    fi
  fi

  for node in $HDAT_PLUGINS_HOSTLIST; do
    if [ $node != "Hostname:" ]; then
        REMOTE_HOST=${node%%.*}
        if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
          ssh ${SSH_OPTIONS} ${LOGNAME}@$node "

             if [ -e $HDAT_LIB_DIR/${HDAT_JAR_FILENAME} ] || [ -e $HDAT_BIN_DIR/${HDAT_BIN_FILENAME} ]; then
                echo -e \`date\` \"$node ${icolor}INFO: ${nocolor}Found ${nocolor}SAS HDAT Plugins installed.\";
             fi

             if [ -e $CUR_HADOOP_HOME/lib/hadoop/lib/${HDAT_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/lib/hadoop/bin/${HDAT_BIN_FILENAME} ]; then
                echo -e \`date\` \"$node ${wcolor}WARN: ${red}Found ${nocolor}Previous version of SAS HDAT Plugins installed in $CUR_HADOOP_HOME.\";
             fi

             if [ -e $CUR_HADOOP_HOME/lib/hadoop/lib/${LASR_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/lib/hadoop/bin/${LASR_BIN_FILENAME} ]; then
                echo -e \`date\` \"$node ${wcolor}WARN: ${red}Found ${nocolor}SAS 9.4 version of SAS HDAT Plugins installed in $CUR_HADOOP_HOME.\";
             fi

             if [ -e $CUR_HADOOP_HOME/lib/${HDAT_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/bin/${HDAT_BIN_FILENAME} ]; then
                echo -e \`date\` \"$node ${wcolor}WARN: ${red}Found ${nocolor}Previous version of SAS HDAT Plugins installed in $CUR_HADOOP_HOME.\";
             fi

             if [ -e $CUR_HADOOP_HOME/lib/${LASR_JAR_FILENAME} ] || [ -e $CUR_HADOOP_HOME/bin/${LASR_BIN_FILENAME} ]; then
                echo -e \`date\` \"$node ${wcolor}WARN: ${red}Found ${nocolor}SAS 9.4 version of SAS HDAT Plugins installed in $CUR_HADOOP_HOME.\";
             fi

          "  2>&1 | tee -a ${LOG_FILE}
        fi
    fi
  done

  # Look for HDAT istalled under product folder
  for node in $HDAT_PLUGINS_HOSTLIST; do
    if [ $node != "Hostname:" ]; then
        REMOTE_HOST=${node%%.*}
        if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
          let serverCount++
          let indx++;

          HH[$indx]="${LOGNAME}@$node"
          WW[$indx]=`ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
              if [ -e $HDAT_HOME_DIR ]; then
                echo -e \"1\";
              else
                echo -e \"0\";
              fi
          " &`
        fi
    fi
  done

  wait

  let errcount=0;

  for i in `seq 0 $indx`; do
    # Check if the value is an interger
    if ! [[ "${WW[$i]}" =~ ^[0-9]+$ ]]; then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR: ${nocolor}Unable to communicate with ${HH[$i]}. Make sure user ${LOGNAME} exists and its ssh keys are properly configured."  2>&1 | tee -a ${LOG_FILE}
      let errcount++
    else
      let count+=${WW[$i]}
    fi
  done

  if [ $errcount -ne 0 ]; then
    exit 1;
  fi

  return $count
}
#==========================================================
# Execute CHECK action
#==========================================================
executeCheckAction()
{
  # Validate HDAT installation on every node that was specified.
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Checking if SAS HDAT Plugins is installed in $HDAT_BASE_DIR."  2>&1 | tee -a ${LOG_FILE}
  echo ""
  for node in $HDAT_PLUGINS_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$REMOTE_HOST" != "$LOCAL_HOST" ]; then
       ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
          if [ -e $HDAT_HOME_DIR ]; then
            count=\`find $HDAT_HOME_DIR -type f | wc -l\`
            echo -e \`date\` \"${node} ${nocolor}INFO:${green} Found${nocolor} SAS HDAT Plugins installed.\";
          else
            echo -e \`date\` \"${node} ${nocolor}INFO:${nocolor} SAS HDAT Plugins installation was not found in $HDAT_BASE_DIR on ${node}.\";
          fi
       "  2>&1 | tee -a ${LOG_FILE}
    else
       checkHDATInstallLocation
    fi
  done

  wait

  if [ "$HDAT_PLUGINS_HOSTLIST" == "" ]; then
      checkHDATInstallLocation
  fi
 
  let count=$?
  if [ $count != 0 ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} ${green}Found ${nocolor}SAS HDAT Plugins is already installed on this node and $count of $serverCount remote nodes." 2>&1 | tee -a ${LOG_FILE}
  else
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} SAS HDAT Plugins installation was not found in $HDAT_BASE_DIR on $LOCAL_HOST_FULLNAME."  2>&1 | tee -a ${LOG_FILE}
  fi
}
#==========================================================
# UNINSTALL HDATPlugins
#==========================================================
removeHDATPlugins()
{
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} *******************************************************************************"
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Uninstalling SAS HDAT Plugins for Hadoop."
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} *******************************************************************************"

  for node in $HDAT_PLUGINS_HOSTLIST; do
    if [ $node != "Hostname:" ]; then
        REMOTE_HOST=${node%%.*}

        if [ "$LOCAL_HOST" == "$REMOTE_HOST" ] ; then
          sudo rm -rf $HDAT_HOME_DIR 2>&1
#          sudo rm -f ${$HDAT_HOME_DIR}/${HDAT_TAR_FILE}*.gz 2>&1
          echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Uninstalling SAS HDAT Plugins for Hadoop." 2>&1 | tee -a ${LOG_FILE}
        else
          echo -e `date` "${node} ${icolor}INFO:${nocolor} Uninstalling SAS HDAT Plugins for Hadoop." 2>&1 | tee -a ${LOG_FILE}

          ssh ${SSH_OPTIONS} ${LOGNAME}@${node} "
              rm -rf $HDAT_HOME_DIR 2>&1
              rm -f ${INSTALL_RUN_DIR}/${HDAT_TAR_FILE}*.gz 2>&1

          "  2>&1 | tee -a ${LOG_FILE}
        fi
    fi
  done
  # Wait on all sub-processes
  wait

  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Validating SAS HDAT Plugins on remote nodes." 2>&1 | tee -a ${LOG_FILE}

  if [ "$HDAT_PLUGINS_HOSTLIST" == "" ]; then
      checkHDATInstallLocation
  fi

  let count=$?
  if [ $count -eq 0 ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Successfully removed SAS HDAT Plugins from all remote nodes." 2>&1 | tee -a ${LOG_FILE}
  else
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Unable to remove SAS HDAT Plugins from $count remote nodes." 2>&1 | tee -a ${LOG_FILE}
  fi
}
#==========================================================
# PARALLEL COPY OF SAS HDAT Plugins
#==========================================================
parallelCreateSASROOT()
{
  for node in $HDAT_PLUGINS_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ]; then
       if [ -e $HDAT_HOME_DIR ]; then
          echo -e `date` "${node} ${ecolor}ERROR:${nocolor} SAS HDAT Plugins is already installed in the current location." 2>&1 | tee -a ${LOG_FILE}
          exit 1;
        fi

        if [ ! -e ${HDAT_BASE_DIR} ]; then
          echo -e `date` "${node} ${icolor}INFO:${nocolor} Creating directory ${HDAT_BASE_DIR}." 2>&1 | tee -a ${LOG_FILE}
          sudo mkdir -p ${HDAT_BASE_DIR};
          rc=$?;
          if [ $rc -ne 0 ]; then
            echo -e `date` "${node} ${ecolor}ERROR:${nocolor} Failed to create directory ${HDAT_BASE_DIR}." 2>&1 | tee -a ${LOG_FILE}
            exit 1;
          fi;
       fi
       sudo chmod -R 0755 $HDAT_BASE_DIR 2>&1
    else
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "

      if [ -e $HDAT_HOME_DIR ]; then
        echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} SAS HDAT Plugins is already installed in the current location.\";
        exit 1;
      fi

      if [ ! -e ${HDAT_BASE_DIR} ]; then
        echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Creating directory ${HDAT_BASE_DIR}.\";
        sudo mkdir -p ${HDAT_BASE_DIR};
        sudo chown ${LOGNAME} ${HDAT_BASE_DIR}
        rc=\$?;
        if [ \$rc -ne 0 ]; then
          echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Failed to create directory ${HDAT_BASE_DIR}.\";
          exit 1;
        fi;
      fi

      # Make sure SHDAT_HOME_DIR is not populated
      if [  -e ${HDAT_HOME_DIR} ]; then
         count=\`ls -1 ${HDAT_HOME_DIR} | wc -l\`

         if [ "\$count" -gt "0" ]; then
           echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Unable to install SAS HDAT Plugins in a folder: ${HDAT_HOME_DIR} that is already populated.\";
           exit 1;
         fi
      fi
      "  2>&1 | tee -a ${LOG_FILE}
    fi
  done

  wait
}
#==========================================================
# PARALLEL COPY OF SAS HDAT Plugins
#==========================================================
copyInstallTarball()
{
  let scpcount=0;
  let nodesCount=0;

  for node in $HDAT_PLUGINS_HOSTLIST; do
      if [ $node != "Hostname:" ]; then
        REMOTE_HOST=${node%%.*}

        if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
          echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Copying SAS HDAT Install file to $node." 2>&1 | tee -a ${LOG_FILE}
          let nodesCount++;

          bash -c "  scp $SCP_OPTIONS ${INSTALL_RUN_DIR}/${HDAT_TAR_FILE}.gz ${LOGNAME}@$node:${HDAT_BASE_DIR} 2>&1;
                     let rc=\$?;
                     if [ \$rc -ne 0 ]; then
                       echo -e -e \`date\` \"$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Unable to copy SAS HDAT Install file to $node.${nocolor}\";
                     fi;
                   "  2>&1 | tee -a ${LOG_FILE}

          let scpcount=(`jobs -p | wc -l`)-1

          if [ $scpcount -ge $MAX_PARALLEL_SCP ]; then
            while [ true ]; do
              sleep 0.5;
              let scpcount=(`jobs -p | wc -l`)-1
              if [ $scpcount -lt $MAX_PARALLEL_SCP ]; then
                break;
              fi;
            done;
          fi;
        fi
    fi
  done

  wait
}
#==========================================================
# Prompt. Returns the response in userInput
#==========================================================
promptYesNo()
{
  userInput=""

  until [ "$userInput" == "$2" ] || [ "$userInput" == "$3" ]; do
    echo " "
    read -p "${1} " userInput
    userInput=`echo -e "$userInput"`
    userInput=`echo $userInput | awk '{print toupper($0)}'`
  done
}
#==========================================================
# Prompt. Returns the response in userInput
#==========================================================
promptYesNo1()
{
select yn in "Yes" "No"; do
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
    esac
done
}
#==========================================================
# INSTALL A NEW SAS HDAT FOR HADOOP
#==========================================================
addHDATPlugins()
{
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} *******************************************************************************"
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Installing SAS HDAT Plugins for Hadoop..."
  echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} *******************************************************************************"
  # Check if HDAT is already installed on current location
  checkHDATInstallLocation
  let count=$?
  if [ "$ACTION" == "ADD" ]; then
    if [ $count != 0 ]; then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} SAS HDAT Plugins is already installed on $count of $serverCount specified remote nodes." 2>&1 | tee -a ${LOG_FILE}
      exit 1
    fi
    parallelCreateSASROOT
  fi

  # Copy Install image to all nodes
  copyInstallTarball

  # Expand image in parallel
  for node in $HDAT_PLUGINS_HOSTLIST; do
      if [ $node != "Hostname:" ]; then
         REMOTE_HOST=${node%%.*}

         if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
           if [ "$ACTION" == "ADD" ]; then
             echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Starting to install SAS HDAT Plugins on $node." 2>&1 | tee -a ${LOG_FILE}
           fi

           ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
              cd ${HDAT_BASE_DIR};
              #========================
              # Finished copying images
              #========================
              echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Expanding SAS HDAT Plugins files.\";
              chmod 755 ${HDAT_BASE_DIR}/${HDAT_TAR_FILE}.gz 2>&1;
              cd ${HDAT_BASE_DIR}
              tar -zxf ${HDAT_TAR_FILE}.gz 2>&1;

              rc=\$?;
              if [ \$rc -ne 0 ]; then
                echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Failed to expand SAS HDAT Plugins file.\";
                exit 1
              fi;

              rm ${HDAT_BASE_DIR}/${HDAT_TAR_FILE}.gz
              #hdfs version |grep apache;
              #let rc=$?
              #if [ $rc -eq 0 ]; then
              #  echo $CUR_HADOOP_HOME/etc/hadoop/hadoop-env.sh
              #  sed -i 's|export HADOOP_CLASSPATH=*|export HADOOP_CLASSPATH=$HADOOP_CLASSPATH:/opt/sas/HDATHome/lib/*|g' $CUR_HADOOP_HOME/etc/hadoop/hadoop-env.sh
              #  let rc1=$?
              #  if [ $rc1 -ne 0 ]; then
              #      echo export HADOOP_CLASSPATH=$HADOOP_CLASSPATH:/opt/sas/HDATHome/lib/* >> $CUR_HADOOP_HOME/etc/hadoop/hadoop-env.sh
              #  fi
              #  #sudo sed -i '14 i\export HADOOP_CLASSPATH='$HDAT_LIB_DIR'/*' $HDAT_BIN_DIR/start-namenode-cas-hadoop.sh
              #fi

              #sed -i '13 i export HADOOP_USER_CLASSPATH_FIRST=yes' $HDAT_BIN_DIR/start-datanode-cas-hadoop.sh
              #sed -i '14 i\export HADOOP_CLASSPATH='$HDAT_LIB_DIR'/*' $HDAT_BIN_DIR/start-datanode-cas-hadoop.sh

              #sed -i '13 i\export HADOOP_USER_CLASSPATH_FIRST=yes' $HDAT_BIN_DIR/start-namenode-cas-hadoop.sh
              #sed -i '14 i\export HADOOP_CLASSPATH='$HDAT_LIB_DIR'/*' $HDAT_BIN_DIR/start-namenode-cas-hadoop.sh
              chmod -R 0755 $HDAT_HOME_DIR 2>&1;
              echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Successfully added SAS HDAT Plugins to ${node}.\";
            "  2>&1 | tee -a ${LOG_FILE}
          ##======================
          ## End of ssh invokation
          ##======================
        fi

        # If a local node, copy file to install root and extract locally
        if [ "$LOCAL_HOST" == "$REMOTE_HOST" ]; then
           if [ "$ACTION" == "ADD" ]; then
              # Copy the install tarball
              sudo cp $INSTALL_RUN_DIR/${HDAT_TAR_FILE}.gz ${HDAT_BASE_DIR}/${HDAT_TAR_FILE}.gz
              sudo chmod -R 0755 ${HDAT_BASE_DIR}/${HDAT_TAR_FILE}.gz
              cd ${HDAT_BASE_DIR}
              sudo tar -zxf ${HDAT_TAR_FILE}.gz 2>&1;
              sudo chmod -R 0755 $HDAT_BIN_DIR/start-*.sh
              # addHadoopClassPathStatement
              sudo rm ${HDAT_BASE_DIR}/${HDAT_TAR_FILE}.gz
              echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Successfully added SAS HDAT Plugins to $LOCAL_HOST_FULLNAME." 2>&1 | tee -a ${LOG_FILE}
           fi
        fi
     fi
  done

  # Wait on all sub-processes
  wait

  if [ "$ACTION" == "ADD" ] && [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Validating SAS HDAT Plugins on remote nodes."

    checkHDATInstallLocation

    let count=$?
    if [ $count -eq $serverCount ]; then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Successfully added SAS HDAT Plugins to all $serverCount remote nodes." 2>&1 | tee -a ${LOG_FILE}
    else 
      let t=$serverCount-$count
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Unable to add SAS HDAT Plugins to $t of $serverCount remote nodes." 2>&1 | tee -a ${LOG_FILE}
    fi
  else
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} SAS HDAT Plugins installation script has completed." 2>&1 | tee -a ${LOG_FILE}
  fi
}

#==========================================================
# Add an export statement to the hadoop-env.sh start script
#==========================================================
addHadoopClassPathStatement()
{
  hdfs version |grep apache
  let rc=$?

  if [ $rc -eq 0 ]; then
    echo $CUR_HADOOP_HOME/etc/hadoop/hadoop-env.sh
    sudo sed -i "s|*export HADOOP_CLASSPATH=*|export HADOOP_CLASSPATH='$HADOOP_CLASSPATH':\/opt\/sas\/HDATHome\/lib\/* |g" $CUR_HADOOP_HOME/etc/hadoop/hadoop-env.sh
    #sudo sed -i 's|<FULL_VERSION>|%hdat_parcel_vernum()-el6 |g' %mytmpdir2/hdatplugins/SASHDAT-%hdat_parcel_vernum()/meta/parcel.json   \n
    let rc1=$?
    if [ $rc1 -ne 0 ]; then
       sudo echo "export HADOOP_CLASSPATH=$HADOOP_CLASSPATH:\/opt\/sas\/HDATHome\/lib\/*" >> $CUR_HADOOP_HOME/etc/hadoop/hadoop-env.sh
    fi
    #sudo sed -i '14 i\export HADOOP_CLASSPATH='$HDAT_LIB_DIR'/*' $HDAT_BIN_DIR/start-namenode-cas-hadoop.sh
  fi
}

#==========================================================
# Check for duplicate actions in comnand line
#==========================================================
checkDuplicateActionError()
{
  ACT1=$1
  ACT2=$2

  if [ "$ACTION" ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Option $ACT1 cannot be used in conjunction with any other action option: [$ACT2]." 2>&1 | tee -a ${LOG_FILE}
    exit 1
  fi
}
#==========================================================
# Check for duplicate actions in comnand line
#==========================================================
checkActionMissingValueError()
{
  ACT1=$1
  ACT2=$2
  #------------------------------------------------
  # Checks if the value starts with a -
  #------------------------------------------------
  let i=`echo $ACT1 | awk '{print index($1, "-")}'`

  if [ "$ACT1" == "//" ] || [ $i == 2 ]; then
    if [ "$ACT2" != "-genconfig" ]; then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Option $ACT2 is missing a value." 2>&1 | tee -a ${LOG_FILE}
      exit 1
    fi

    return 1
  fi
}
#==========================================================
# OUTER BLOCK
#==========================================================
echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} Initializing script environment." 2>&1 | tee -a ${LOG_FILE}
showHadoopHome
# Initialize variables
let IS_NOSUDO=0
# Hadoop commands
HADOOP_CMD_RM="-rm"
HADOOP_CMD_RMR="-rm -r"
HADOOP_CMD_MKDIR="-mkdir -p"
HDFS_USER=hdfs;
#==========================================================
# Parse input parameters
#==========================================================
cd $HDAT_BIN
let sequence=0

while [ "$1" != "" ]; do
  let sequence++
  case $1 in
    -x )
      let IS_NOSUDO=1
      shift 1
      if [ $sequence -ne 1 ]; then
        echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Option -x must be the first one to be specified." 2>&1 | tee -a ${LOG_FILE}
        exit 1
      fi
      ;;
    -add )
      checkDuplicateActionError $1 $ACTION
      ACTION="ADD"
      shift 1
      ;;
    -remove )
      checkDuplicateActionError $1 $ACTION
      ACTION="REMOVE"
      shift 1
      ;;
    -hostfile )
      HDAT_HOST_FILE=`replaceSpaces $2`
      HDAT_HOST_FILE=`trimSpaces $HDAT_HOST_FILE`
      shift 2
      checkActionMissingValueError "/${HDAT_HOST_FILE}/" -hostfile
      let IS_HOSTOPTION=1
      ;;
    -host )
      HDAT_PLUGINS_HOSTLIST=`replaceCommasBySpaces $2`
      echo $HDAT_PLUGINS_HOSTLIST
      shift 2
      checkActionMissingValueError "/${HDAT_PLUGINS_HOSTLIST}/" -host
      let IS_HOSTOPTION=1
      ;;
    -hdfsuser )
      HDFS_USER=`replaceSpaces $2`
      HDFS_USER=`trimSpaces $HDFS_USER`
      shift 2
      checkActionMissingValueError "/${HDFS_USER}/" -hdfsuser
      ;;
    -nodelist )
      checkDuplicateActionError $1 $ACTION
      ACTION="NODELIST"
      shift 1
      ;;
    -hdathome )
      HDAT_BASE_DIR=`replaceSpaces $2`
      HDAT_BASE_DIR=`trimSpaces $HDAT_BASE_DIR`
      HDAT_HOME_DIR=$HDAT_BASE_DIR/HDATHome
      HDAT_LIB_DIR=$HDAT_HOME_DIR/lib
      HDAT_BIN_DIR=$HDAT_HOME_DIR/bin
      shift 2
      checkActionMissingValueError "/${HDAT_BASE_DIR}/" -hdathome
      ;;
    -version )
      checkDuplicateActionError $1 $ACTION
      ACTION="VERSION"
      shift 1;
      ;;
    -check )
      checkDuplicateActionError $1 $ACTION
      ACTION="CHECK"
      shift 1;
      ;;
    -env )
      checkDuplicateActionError $1 $ACTION
      ACTION="ENV"
      shift 1;
      ;;
    -h|-help )
      printSyntax "${THIS_PROGRAM}"
      ;;
    * )
      echo -e ""
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} \"${1}\" is an invalid option. Enter -h or -help for help."
      exit 1
      ;;
  esac
done
#==========================================================
# PERFORM IMMEDIATE ACTION AND EXIT
#==========================================================
case $ACTION in
  VERSION )
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} SAS HDAT Plugins version info: $HDAT_PRODUCT_VERSION"
    exit 0;
    ;;

  ENV )
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} =================================================="
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor}        INSTALL SCRIPT ENVIRONMENT VARIABLES"
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} =================================================="
    dumpEnvironment
    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} =================================================="
    exit 0
    ;;

  NODELIST )
    hdpnodes=`getNodesList`
    RC=$?
    if [ $RC -ne 0 ]; then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} $hdpnodes" 2>&1 | tee -a ${LOG_FILE}
      exit 1
    fi

    echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} List of data nodes:" 2>&1 | tee -a ${LOG_FILE}
    for each in $hdpnodes; do
      if [ $each != "Hostname:" ]; then
         echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor}  $each" 2>&1 | tee -a ${LOG_FILE}
      fi
    done

    exit 0
    ;;
  * )
    ;;
esac
#==========================================================
# Check Install script
#==========================================================
if [ "$ACTION" == "ADD" ] && [ "$HDAT_INSTALL_IMAGE" == "" ]; then
    HDAT_INSTALL_IMAGE=${INSTALL_RUN_DIR}/${HDAT_TAR_FILE}.gz
    if [ -f "${HDAT_INSTALL_IMAGE}" ]; then
        echo -e `date` "$LOCAL_HOST_FULLNAME ${icolor}INFO:${nocolor} SAS HDAT install tarball $HDAT_INSTALL_IMAGE is found." 2>&1 | tee -a ${LOG_FILE}
    else
        echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} No install tarball $HDAT_INSTALL_IMAGE was found in ${INSTALL_RUN_DIR}." 2>&1 | tee -a ${LOG_FILE}
        exit 1
    fi
fi
#==========================================================
if [ "$ACTION" == "ADD" ]; then
  isValid=`validateFileLocation ${HDAT_INSTALL_IMAGE}`
  if [ "${isValid}" != ""  ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${isValid}"
    exit 1
  fi
fi
#==========================================================
if [ "$ACTION" == "ADD" ] || [ "$ACTION" == "REMOVE" ]; then
  isValid=`validateDirectoryLocation ${HADOOP_CORE_LIB}`

  if [ "${isValid}" != ""  ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${isValid}" 2>&1 | tee -a ${LOG_FILE}
    exit 1
    fi
fi
#==========================================================
# Populate HDAT_PLUGINS_HOSTLIST variable
#==========================================================
if [ "${HDAT_PLUGINS_HOSTLIST}" != "" ] && [ "${HDAT_HOST_FILE}" != "" ]; then
   echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} Options -hostfile and -host are mutually exclusive." 2>&1 | tee -a ${LOG_FILE}
   exit 1
fi
#----------------------------------------------------------------------------
# Resolve the host list. If user does not specify the list of hosts, we will
# get it from the cluster.
#----------------------------------------------------------------------------
if [ "$ACTION" == "ADD" ] || [ "$ACTION" == "REMOVE" ] || [ "$ACTION" == "CHECK" ] ; then
  if [ "$HDAT_PLUGINS_HOSTLIST" == "" ] && [ "$HDAT_HOST_FILE" == "" ] && [ "$HDAT_HOSTS" == "" ] && [ "$HDAT_HOSTS_FILE" == "" ]; then
    HDAT_PLUGINS_HOSTLIST=`getNodesList`
    RC=$?

    if [ $RC -ne 0 ];then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} $HDAT_PLUGINS_HOSTLIST" 2>&1 | tee -a ${LOG_FILE}
      HDAT_PLUGINS_HOSTLIST=""
    else
      checkNodesList
    fi
    #----------------------------------------------------------------------------
    # If the list of data nodes is still not found, we will have to throw an error
    # and ask the user to specify it.
    #----------------------------------------------------------------------------
    if [ "$HDAT_PLUGINS_HOSTLIST" == "" ] && [ "$HDAT_HOST_FILE" == "" ] && [ "$HDAT_HOSTS" == "" ] && [ "$HDAT_HOSTS_FILE" == "" ]; then
      echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} One of the following two options must be specified: -hostfile or -host." 2>&1 | tee -a ${LOG_FILE}
      exit 1
    fi
  fi
fi

if [ "${HDAT_PLUGINS_HOSTLIST}" == "" ] && [ "${HDAT_HOST_FILE}" == "" ] && [ "${HDAT_HOSTS_FILE}" != "" ]; then
  HDAT_HOST_FILE=${HDAT_HOSTS_FILE}
fi

if [ "${HDAT_HOST_FILE}" != "" ]; then
  # make sure the specified host list file is valid
  isValid=`validateFileLocation ${HDAT_HOST_FILE}`

  if [ "${isValid}" != ""  ]; then
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi
  
  # Populate HDAT_PLUGINS_HOSTLIST variable with the list of hosts from file
  HDAT_PLUGINS_HOSTLIST=`cat ${HDAT_HOST_FILE} | sed  "s/#.*$//;/^$/d"`
fi

# If nothing was specified in the hosts or hosts list, we will use HDAT_HOSTS
if [ "${HDAT_PLUGINS_HOSTLIST}" == "" ]; then
  HDAT_PLUGINS_HOSTLIST=`trimSpaces ${HDAT_HOSTS}`
fi
#==========================================================
# PERFORM NON IMMEDIATE ACTION
#==========================================================
case $ACTION in
  ADD )
    addHDATPlugins
    ;;
  CHECK )
    executeCheckAction
    exit
    ;;
  REMOVE )
    removeHDATPlugins
    ;;
  * )
    echo -e ""
    echo -e `date` "$LOCAL_HOST_FULLNAME ${ecolor}ERROR:${nocolor} \"${ACTION}\" is an invalid action. Enter -h or -help for help." 2>&1 | tee -a ${LOG_FILE}
    exit 1
    ;;
esac
#==========================================================
exit 0
