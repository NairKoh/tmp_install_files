#!/bin/bash
# Copyright 2008,2010,2013 SAS Institute Inc.
# SAS Campus Drive, Cary, North Carolina 27513, USA.
# All rights reserved.
#
# License: This script and its contents is property of SAS Institute and
# is to be used in conjunction with SAS software and tools only. You may not
# copy, modify, or redistribute, in whole or in part, any portion of this
# script without expressed written permission from SAS Institute.
#
##H=======================================
##HSAS Embedded Process for Hadoop
##H=======================================
##HAction options syntax:
##H
##H sasep-admin.sh -add [-host <HostNames> | -hostfile <FileName>] [-yarnrm <resourcemanagerhost:port>] [-maxparallel <number>] [-hdfsuser <UserID>] [-nohostcheck]
##H
##H                -genconfig [<HDFSFileName>] [-force]
##H
##H                -remove [-host <HostNames> | -hostfile <FileName>] [-yarnrm <resourcemanagerhost:port>] [-hdfsuser <UserID>] [-nohostcheck]
##H
##H                -sync [-host <HostNames> | -hostfile <FileName>] [-maxparallel <number>] [-nohostcheck]
##H
##HWhere:
##H
##H -add       : Installs SAS Embedded Process on the provided list of hosts. If the list of hosts is not provided, the script retrieves the list
##H              of YARN Node Manager nodes from the cluster configuration.
##H
##H -sync      : Syncs the local SAS Embedded Process install with  the provided list of hosts. If the list of hosts is not provided, the script
##H              retrieves the list of YARN Node Manager nodes from the cluster configuration.
##H
##H -genconfig : Generates the SAS Embedded Process configuration file under <SAS_EP_HOME>/conf on the local file system. If running with a user with sudo privileges,
##H              the script creates the ep-config.xml configuration file and writes it to both the EPInstallDir/SASEPHome/conf directory on
##H              the local file system and the /sas/ep/config/ directory on HDFS. You can change the filename and HDFS location by using the HDFS-filename
##H              argument. HDFS-filename argument must be the fully qualified HDFS path name where the configuration file is stored.
##H              The default configuration file name on HDFS is /sas/ep/config/ep-config.xml.
##H              Use the -force option to overwrite existing configuration files.
##H
##H              The following example generates configuration files under <SAS_EP_HOME>/conf on the local file system and the ep-config.xml
##H              configuration file under /sas/ep/config on HDFS. If running the script with a user that does not have sudo privileges, the script
##H              generates configuration file under <SAS_EP_HOME>/conf on the local file system only:
##H
##H              #> ./sasep-admin.sh -genconfig
##H
##H              The following example overwrites the configuration file under <SAS_EP_HOME>/conf on the local file system and
##H              /sas/ep/config/ep-config.xml configuration file on HDFS, if it already exists:
##H
##H              #> ./sasep-admin.sh -genconfig -force
##H
##H              The following example generates configuration files under <SAS_EP_HOME>/conf on the local file system and the specified
##H              configuration file on HDFS:
##H
##H              #> ./sasep-admin.sh -genconfig /home/hadoop/ep-config.xml
##H
##H              If you decide to generate the configuration file on a non-default HDFS location, you must set the sas.ep.config.file property
##H              in the mapred-site.xml to the value you specify in the -genconfig option.
##H
##H              The -genconfig option creates two identical configuration files under <SAS_EP_HOME>/conf on the local file system: ep-config.xml and
##H              sasep-site.xml. The sasep-site.xml file might be copied to the client side under a folder that is in the classpath.
##H              When sasep-site.xml file is loaded from the classpath, the configuration file on the HDFS location is not used. However, if
##H              sasep-site.xml is not found in the classpath, a configuration file must exist on HDFS either on the default HDFS location
##H              /sas/ep/config/ep-config.xml or in the location that is set in sas.ep.config.file property.
##H
##H -hdfsuser  : Specifies the user name with write access to the HDFS root folder. The user name is used to copy configuration files to HDFS.
##H              Default: hdfs, mapr for MapR clusters.
##H
##H -host      : A host or a list of hosts, separated by spaces or comma. Options -hostfile and -host are mutually exclusive.
##H              For example: -host "server1 server2 server3" or -host server1 or "host1,host2, host3 , host4"
##H
##H -hostfile  : The full path of a file containing a list of hosts. Options -hostfile and -host are mutually exclusive.
##H
##H -yarnrm    : Specifies the YARN Resource Manager web application host name and port number in the format <hostname:port>. This option may be used when
##H              the yarn-site.xml property file is not present in the Hadoop configuration folder, or the folder where the yarn-site.xml resides is not in the path.
##H              If not specified, the SAS Embedded Priocess admin script will look for the YARN Resource Manager web application host name and port number in the yarn-site.xml.
##H
##H -maxparallel : Specifies the maximum number of parallel copies between master and slave nodes. Default is 10.
##H
##H -nohostcheck : Disables strict host key checking for any SSH operations.
##H
##H -remove    : Removes SAS Embedded Process from the provided host or list of hosts. If the list of hosts is not provided, the script retrieves the
##H              list of YARN Node Manager nodes from the cluster configuration.
##H
##HInformational options syntax:
##H
##H sasep-admin.sh -check [-host <HostNames> | -hostfile <FileName>] [-yarnrm <resourcemanagerhost:port>] [-hdfsuser <UserID>] [-nohostcheck]
##H                -env
##H                -hadoopversion
##H                -nodelist
##H                -yarnnodes [-yarnrm <resourcemanagerhost:port>]
##H                -version
##H
##HWhere:
##H
##H -check     : Checks if the SAS Embedded Process is installed under current install folder on remote hosts.
##H
##H -env       : Displays the SAS Embedded Process install script and Hadoop configuration environment.
##H
##H -hadoopenv : Displays the 'hadoop' command JVM environment and Hadoop configuration object.
##H
##H -nodelist  : Displays all live data nodes on the cluster. This option requires sudo privileges.
##H
##H -yarnnodes : Displays all nodes where a YARN Node Manager can be found.
##H
##H -version   : Displays SAS Embedded Process version.
##H
##H -hadoopversion : Displays Hadoop version.
##H
##HData Connector Security options syntax:
##H
##H sasep-admin.sh -security [deploy | reset] [-force] [-hdfsuser <UserID>] [-host <HostNames> | -hostfile <FileName>] [-yarnrm <resourcemanagerhost:port>] [-nohostcheck]
##H
##HWhere:
##H
##H -security  : Deploys or resets Data Connector and Embedded Process security settings. Use -force option to overwrite current settings.
##H              Security options are:
##H              . deploy : Deploys security settings to remote nodes.
##H              . reset  : Restores default security configuration settings.
##H
##HLicense file options syntax:
##H
##H sasep-admin.sh -license [deploy | remove] [-force] [-hdfsuser <UserID>] [-host <HostNames> | -hostfile <FileName>] [-yarnrm <resourcemanagerhost:port>] [-nohostcheck]
##H
##HWhere:
##H
##H -license   : Deploys or removes the seitinit.sas license file to/from nodes. Use -force option to overwrite current settings.
##H              License options are:
##H              . deploy : Deploys setinit to remote nodes.
##H              . remove : Removes setinit from nodes.
##XEND
#==========================================================
black='\033[0;30m'
darkgray='\033[1;30m'
blue='\033[0;34m'
lightblue='\033[1;34m'
green='\033[0;32m'
lightgreen='\033[1;32m'
cyan='\033[0;36m'
lightcyan='\033[1;36m'
red='\033[0;31m'
lightred='\033[1;31m'
purple='\033[0;35m'
lightpurple='\033[1;35m'
brownorange='\033[0;33m'
yellow='\033[1;33m'
lightgray='\033[0;37m'
white='\033[1;37m'
nocolor='\033[0m'
dcolor=${nocolor}
icolor=${nocolor}
ecolor=${red}
wcolor=${yellow}
#==========================================================
THIS_PROGRAM=$0
SAS_EP_COMMAND_PATH=`dirname $0`
#==========================================================
LOCAL_HOST_FULLNAME=`hostname`
LOCAL_HOST=${LOCAL_HOST_FULLNAME%%.*}
#==========================================================
USER_LOCAL_DIR=`pwd`
cd $SAS_EP_COMMAND_PATH
SAS_EP_BIN=`pwd`
SAS_EP_HOME=`dirname $SAS_EP_BIN`
SAS_EP_SASEXE=${SAS_EP_HOME}/sasexe
SAS_EP_MISC_DEPLOYMENT=${SAS_EP_HOME}/misc/deployment
SAS_EP_INSTALL_ROOT=`dirname $SAS_EP_HOME`
SAS_EP_JARS=$SAS_EP_HOME/jars
SAS_EP_LICENSE_INSTALL_DIR=$SAS_EP_HOME/license
SAS_EP_LICENSE_SETINIT_FILE=setinit.sas
SAS_EP_SECURITY_INSTALL_DIR=$SAS_EP_HOME/security
SAS_EP_SECURITY_CONFIG_FILE=dcsecurity.properties
SAS_EP_SECURITY_CONFIG_FILE_VARIABLE=$SAS_EP_SECURITY_INSTALL_DIR/$SAS_EP_SECURITY_CONFIG_FILE
SAS_EP_JNI_LIBRARY=libhdepjni.so
SAS_EP_DEFAULT_CONFIG_FILE_NAME=/sas/ep/config/ep-config.xml
SAS_EP_LOCAL_CONFIG_FOLDER=$SAS_EP_HOME/conf
SAS_EP_LOCAL_CONFIG_FILE=$SAS_EP_LOCAL_CONFIG_FOLDER/ep-config.xml
SAS_EP_SITE_XML_FILE=$SAS_EP_LOCAL_CONFIG_FOLDER/sasep-site.xml
#==========================================================
cd $USER_LOCAL_DIR
#==========================================================
SSH_OPTIONS="-x -q -o PasswordAuthentication=no"
# Recursive -r, preserve archive (symbolic links, permissions) -a, -P show progress,
# use compression -z, make output human readable -h
RSYNC_OPTIONS="-r -a -z -h"
SCP_OPTIONS="-q -o PasswordAuthentication=no"
MYPID=$$
DFS_ADMIN_UTIL_CLASSNAME=com.sas.access.hadoop.ep.utils.AdminUtil
# Maximum number of parallel copies between master and slaves
MAX_PARALLEL_SCP=10
MAX_PARALLEL_RSYNC=10
#==========================================================
let IS_LINK_HADOOP_LIB=0
let IS_FORCE_OVERWRITE=0
let IS_HOSTOPTION=0
#==========================================================
SAS_EP_PRODUCT_VERSION=16.00000
#==========================================================
# Get the latest SAS EP JAR file
#==========================================================
getLatestEPJar()
{
  latest=`cd ${SAS_EP_JARS}; ls sasep-hdp2-*.jar | egrep -v "source|javadoc" | sort | tail -1`
  echo ${SAS_EP_JARS}/$latest
}

SAS_EP_JAR_FILE=`getLatestEPJar`
#==========================================================
SAS_EP_JAR_LINK_BASENAME=sasep.jar
SAS_EP_JAR_LINK_NAME=${SAS_EP_JARS}/${SAS_EP_JAR_LINK_BASENAME}
#==========================================================
# EP Configuration file default options
#==========================================================
SAS_EP_TKPATH=""
SAS_EP_CLASSPATH=""
SAS_EP_LD_PRELOAD=""
SAS_EP_CONFIG_LITTLE_ENDIAN="true"
#==========================================================
# The call to this function removes leading and trailing
# spaces
#==========================================================
trimSpaces()
{
  echo -e "$*"
}
#==========================================================
# The call to this function replaces spaces by a back
# slash (\ ) followed by a space.
#==========================================================
replaceSpaces()
{
  echo -e $*| awk '{str=$0; gsub(/ /, "\\ ", str); print str}'
}
#==========================================================
# The call to this function replaces commas by space
#==========================================================
replaceCommasBySpaces()
{
  echo -e $*| awk '{str=$0; gsub(/,/, " ", str); print str}'
}
## ===============================================================
# Check if specified user is valid in the system
#
isUserExist2()
{
  userName=$1

  if [ -z $1 ]; then
    echo -e n
    return
  fi

  # Check if the user exists in the system
  id=`id ${userName} > /dev/null; echo -e $?`

  if [ $id -ne 0 ]; then
    echo -e n
    return
  fi

  echo -e y
  return
}
#==========================================================
# Display the help information that is in the top of the
# file.
printSyntax()
{
  THIS_FILE=${1}

  while read record; do
    head=`echo -e "$record" | cut -c1-3`

    if [ "$head" = "##H" ]; then
      echo -e "$record" | cut -c4-
    else if [ "$head" = "##X" ]; then
      exit -1
    fi
    fi
  done < $THIS_FILE

  exit -1
}
## ===============================================================
# Validate a directory location
#
validateDirectoryLocation()
{
  dirName=$1

  if [ ! -e $dirName ]; then
    echo -e "Directory $dirName does not exist."
    return
  fi

  if [ ! -d $dirName ]; then
    echo -e "The name $dirName is not a directory."
    return
  fi

  #if [ ! -w $dirName ]; then
  #  echo -e "Directory $dirName does not have write permission."
  #  return
  #fi
}
## ===============================================================
# Validate a file location
#
validateFileLocation()
{
  fileName=$1

  if [ ! -e $fileName ]; then
    echo -e "File $fileName does not exist."
    return
  fi

  if [ ! -f $fileName ]; then
    echo -e "The name $fileName is not a regular file."
    return
  fi

  if [ ! -r $fileName ]; then
    echo -e "File $fileName does not have read permission."
    return
  fi
}
## ===============================================================
# Generate EP Server configuration file. This file will be stored
# on HDFS under /sas/ep/config/ep-config.xml
#
generateEPConfigFile()
{
  #-------------------------------
  # LOCAL
  #-------------------------------
  checkLocalConfigFileExistence
  if [ $? -eq 1 ]; then # IF FOUND
    if [ $IS_FORCE_OVERWRITE -eq 0 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Local configuration file exists and cannot be overwritten. Use -force option to overwrite it."
      exit 1
    else
      removeLocalEPConfigFile
    fi
  fi
  #-------------------------------
  # HDFS
  #-------------------------------
  checkHDFSConfigFileExistence
  if [ $? -eq 1 ]; then # IF FOUND
    if [ $IS_FORCE_OVERWRITE -eq 0 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Configuration file exists and cannot be overwritten. Use -force option to overwrite it."
      exit 1
    else
      removeHDFSEPConfigFile
    fi
  fi

  SAS_EP_TKPATH="$SAS_EP_SASEXE"
  SAS_EP_CLASSPATH=${SAS_EP_JAR_LINK_NAME}

  if [ "$HCAT_CLASSPATH" != "" ]; then
    SAS_EP_CLASSPATH="${SAS_EP_CLASSPATH},$HCAT_CLASSPATH"
  else
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Unable to determine if HCatalog is installed on the cluster, therefore its class path will not be added to the SAS Embedded Process configuration."
  fi

  SAS_EP_LD_PRELOAD="$JAVA_LIBJSIG"
  let indx=0
  EP_CONFIG_OPTIONNAME_LIST=(sas.ep.tkpath
                             sas.ep.classpath
                             sas.ep.ld.preload
                             sas.ep.home
                             sas.ep.little.endian
                             sas.ep.version.major
                             sas.ep.version.minor
                             sas.ep.version.delta
                             sas.ep.version.implementation
                             sas.ep.hdp.version
                            )

  EP_CONFIG_OPTIONVALUE_LIST=(${SAS_EP_TKPATH}
                              ${SAS_EP_CLASSPATH}
                              ${SAS_EP_LD_PRELOAD}
                              ${SAS_EP_HOME}
                              ${SAS_EP_CONFIG_LITTLE_ENDIAN}
                              ${SAS_EP_CONFIG_VERSION_MAJOR}
                              ${SAS_EP_CONFIG_VERSION_MINOR}
                              ${SAS_EP_CONFIG_VERSION_DELTA}
                              ${SAS_EP_CONFIG_VERSION_IMPLEMENTATION}
                              ${EP_HDP_VERSION}
                             )

  optionCount=${#EP_CONFIG_OPTIONNAME_LIST[*]}
  valueCount=${#EP_CONFIG_OPTIONVALUE_LIST[*]}

  while true; do
    GENCONFIGPARM="${GENCONFIGPARM} ${EP_CONFIG_OPTIONNAME_LIST[$indx]}=${EP_CONFIG_OPTIONVALUE_LIST[$indx]}"
    let indx++;
    if [ $indx -eq $optionCount ]; then
      break;
    fi
  done

  echo -e `date` "localhost ${icolor}INFO:${nocolor} Generating configuration file under $SAS_EP_LOCAL_CONFIG_FOLDER."
  #--------------------------------------------------------------
  # Generate a configuration file locally
  # SAS_EP_LOCAL_CONFIG_FILE and SAS_EP_SITE_XML_FILE
  #--------------------------------------------------------------
  HDFS_LOGIC="hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -genconfig file://${SAS_EP_LOCAL_CONFIG_FILE} ${GENCONFIGPARM}"
  eval "${HDFS_LOGIC}" 2>&1
  rc=$?
  if [ $rc -ne 0 ];then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Failed to create configuration files under $SAS_EP_LOCAL_CONFIG_FOLDER."
    exit 1
  fi

  cp ${SAS_EP_LOCAL_CONFIG_FILE} ${SAS_EP_SITE_XML_FILE}
  #--------------------------------------------------------------
  # Generate a configuration file on HDFS if SUDO is allowed
  #--------------------------------------------------------------
  if [ $IS_NOSUDO -eq 0 ]; then
    echo -e `date` "localhost ${icolor}INFO:${nocolor} Generating configuration file $EP_FULL_CONFIG_FILE_PATH on Distributed File System."
    #--------------------------------------------------------------
    # Generate a configuration file on HDFS
    #--------------------------------------------------------------
    HDFS_LOGIC="
        export HADOOP_USER_CLASSPATH_FIRST=yes
        export HADOOP_CLASSPATH=${SAS_EP_JAR_FILE}
        hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -genconfig ${EP_FULL_CONFIG_FILE_PATH} ${GENCONFIGPARM}
        rc=\$?;
        if [ \$rc -ne 0 ];then
          echo -e \`date\` \"localhost ${ecolor}ERROR:${nocolor} Failed to create configuration file $EP_FULL_CONFIG_FILE_PATH on Distributed File System.\"
          exit 1
        fi
    "

    $RUNASHDFSUSER "${HDFS_LOGIC}" 2>&1
    rc=$?

    if [ $rc -ne 0 ]; then
      exit 1;
    fi

    return $rc
  else
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} User $LOGNAME does not have privileges to create configuration file $EP_FULL_CONFIG_FILE_PATH on HDFS."
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Configuration file must be manually copied from local configuration folder to HDFS location $EP_FULL_CONFIG_FILE_PATH."
  fi
}
#===============================================================
# Get HCatalog class path
#===============================================================
getHCatalogClassPath()
{
  which hcat > /dev/null 2>&1

  if [ $? -eq 0 ]; then
    HCAT_CLASSPATH=`files=\`hcat -classpath | awk -F: '{
                                                     for (i=1; i <= NF; i++)
                                                     {
                                                       print $i;
                                                     }
                                                   }' | egrep -i "/hive/lib/|hcat" \`;
               for each in $files; do
                 dirname $each;
               done | sort -u`;

    unset s;
    let i=0;

    for e in $HCAT_CLASSPATH; do
      if [ $i -ne 0 ]; then
        s="${s},"
      fi

      let i++
      s="${s}${e}/*"
    done;

    HCAT_CLASSPATH=$s
    return 0
  fi

  return 1
}

#==========================================================
# Get Hadoop version
#==========================================================
setSpecificVersionCommands()
{
  HADOOP_CMD_RM="-rm"
  HADOOP_CMD_RMR="-rm -r"
  HADOOP_CMD_MKDIR="-mkdir -p"
}
#==========================================================
# Create EP configuration fodler under SAS_EP_HOME
#==========================================================
createLocalConfigFolder()
{
  if [ ! -e $SAS_EP_HOME/conf ]; then
    mkdir $SAS_EP_HOME/conf
    if [ $? -ne 0 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Failed to create directory ${SAS_EP_HOME}/conf}."
      exit 1
    fi;
  fi
}
#==========================================================
# Check if EP configuration exists # 1=exists
#==========================================================
checkLocalConfigFileExistence()
{
  if [ -e $SAS_EP_LOCAL_CONFIG_FILE ]; then
    return 1
  else
    return 0
  fi
}
#==========================================================
# Check if EP configuration exists # 1=exists
#==========================================================
checkHDFSConfigFileExistence()
{
  hadoop fs -test -e $EP_FULL_CONFIG_FILE_PATH
  rc=$?

  if [ $rc -eq 0 ]; then
   return 1
  fi

  return 0
}
#==========================================================
# Remove configuration file on LOCAL file system
#==========================================================
removeLocalEPConfigFile()
{
  #----------------------------------------------------------
  # Remove all configuration file under local conf folder
  #----------------------------------------------------------
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Removing SAS Embedded Process configuration file under $SAS_EP_LOCAL_CONFIG_FOLDER."
  rm -f $SAS_EP_LOCAL_CONFIG_FOLDER/*
  return 0
}
#==========================================================
# Remove configuration file on HDFS
#==========================================================
removeHDFSEPConfigFile()
{
  checkHDFSConfigFileExistence

  if [ $? -eq 0 ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Configuration file $EP_FULL_CONFIG_FILE_PATH was not found on HDFS."
    return 0
  fi
  #--------------------------------------------------------------
  # Remove configuration file from HDFS if SUDO is allowed
  #--------------------------------------------------------------
  if [ $IS_NOSUDO -eq 0 ]; then
    echo -e `date` "localhost ${icolor}INFO:${nocolor} Removing SAS Embedded Process configuration file $EP_FULL_CONFIG_FILE_PATH"
    HDFS_LOGIC="hadoop fs $HADOOP_CMD_RM $EP_FULL_CONFIG_FILE_PATH"

    $RUNASHDFSUSER "${HDFS_LOGIC}" 2>&1

    if [ $? -ne 0 ]; then
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} Failed to remove configuration file $EP_FULL_CONFIG_FILE_PATH."
      return 1
    fi
  else
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} User $LOGNAME does not have privileges to remove configuration file from HDFS: $EP_FULL_CONFIG_FILE_PATH."
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Configuration file $EP_FULL_CONFIG_FILE_PATH must be manually removed by an HDFS super user."
  fi

  return 0
}
#==========================================================
# Get a list of LIVE data nodes installed on the cluster
#==========================================================
getDataNodesList()
{
  if [ $EP_IS_MAPR -eq 1 ]; then
    MAPRCLI=`which maprcli 2> /dev/null`
    #----------------------------------------------------------
    # MapR specific
    #----------------------------------------------------------
    if [ "$MAPRCLI" != "" ]; then
      $RUNASHDFSUSER "$MAPRCLI node list -columns service" | egrep "fileserver|datanode" | awk '{hostList=hostList $2 " "} END {print hostList}'
      rc=$?
      return $rc
    else
      return 1
    fi
  fi
  #----------------------------------------------------------
  # Make sure we have privileges
  #----------------------------------------------------------
  if [ $IS_NOSUDO -eq 1 ]; then
    echo "Automatic detection of cluster topology is not available when running the install script with a user without sudo privileges."
    return 1
  fi
  #----------------------------------------------------------
  # Call AdminUtil
  #----------------------------------------------------------
  HDFS_LOGIC="
      export HADOOP_USER_CLASSPATH_FIRST=yes
      export HADOOP_CLASSPATH=${SAS_EP_JAR_FILE}
      hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -listdatanodes
      "

  $RUNASHDFSUSER "${HDFS_LOGIC}" 2>&1

  let rc=$?

  if [ $rc -ne 0 ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Please make sure the top folders of the install location have read and execute permissions."
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Please make sure user $HDFS_USER is a Hadoop superuser."
  fi

  return $rc
}
#==========================================================
# Get a list of LIVE data nodes installed on the cluster
#==========================================================
getMapRYarnNodesList()
{
  MAPRCLI=`which maprcli 2> /dev/null`
  #----------------------------------------------------------
  # MapR specific
  #----------------------------------------------------------
  if [ "$MAPRCLI" != "" ]; then
    #----------------------------------------------------------
    # MapR major version number.
    #----------------------------------------------------------
    let MAPR_TARGETVERSION=`$RUNASHDFSUSER "$MAPRCLI config load -keys mapr.targetversion" | awk '{ if ($1 != "mapr.targetversion") print $1;}' | awk -F. '{print $1}'`

    if [ $MAPR_TARGETVERSION -lt 6 ]; then
      $RUNASHDFSUSER "$MAPRCLI node list -columns service" | egrep "resourcemanager|nodemanager" | awk '{hostList=hostList $2 " "} END {print hostList}'
    else
      $RUNASHDFSUSER "$MAPRCLI node list -columns service" | egrep "resourcemanager|nodemanager" | awk '{hostList=hostList $1 " "} END {print hostList}'
    fi
    rc=$?
    return $rc
  else
    echo "MapR command line interface maprcli not found in the path."
    return 1
  fi
}
#==========================================================
# Get a list of YARN node managers nodes
#==========================================================
getYarnNodesList()
{
  if [ -z "$YARN_RESOURCE_MANAGER" ] && [ $EP_IS_MAPR -eq 1 ]; then
    getMapRYarnNodesList
    rc=$?
    return $rc
  fi

  hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -listyarnnodes $YARN_RESOURCE_MANAGER 2>&1

  let rc=$?

  if [ $rc -ne 0 ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to retrieve a list of YARN Node Manager nodes."
  fi

  return $rc
}
#==========================================================
# Dump environment
#==========================================================
dumpEnvironment()
{
  echo -e `date` "localhost ${icolor}INFO:${nocolor} HADOOP_CORE_DIR=$HADOOP_CORE_DIR"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} HADOOP_CORE_LIB=$HADOOP_CORE_LIB"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} HADOOP_HOME=$EP_HADOOP_HOME"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} HCAT_CLASSPATH=$HCAT_CLASSPATH"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} HDFS_USER=$HDFS_USER"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} IS_LINK_HADOOP_LIB=$IS_LINK_HADOOP_LIB"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} IS_MAPR=$EP_IS_MAPR"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} JAVA_HOME=$EP_JAVA_HOME"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} JAVA_LIBJSIG=$JAVA_LIBJSIG"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} JAVA_LIBRARY_PATH=$EP_JAVA_LIBRARY_PATH"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} MAPRED_FRAMEWORK=$EP_MAPRED_FRAMEWORK"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_BIN=$SAS_EP_BIN"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_COMMAND_PATH=$SAS_EP_COMMAND_PATH"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} EP_FULL_CONFIG_FILE_PATH=$EP_FULL_CONFIG_FILE_PATH"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_CONFIG_VERSION_MAJOR=$SAS_EP_CONFIG_VERSION_MAJOR"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_CONFIG_VERSION_MINOR=$SAS_EP_CONFIG_VERSION_MINOR"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_CONFIG_VERSION_DELTA=$SAS_EP_CONFIG_VERSION_DELTA"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_CONFIG_VERSION_IMPLEMENTATION=$SAS_EP_CONFIG_VERSION_IMPLEMENTATION"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_HOME=$SAS_EP_HOME"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_INSTALL_ROOT=$SAS_EP_INSTALL_ROOT"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_JARS=$SAS_EP_JARS"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_JAR_FILE=${SAS_EP_JAR_FILE}"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_JAR_LINK_NAME=$SAS_EP_JAR_LINK_NAME"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_PRODUCT_VERSION=$SAS_EP_PRODUCT_VERSION"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS_EP_SASEXE=$SAS_EP_SASEXE"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} USER_LOCAL_DIR=$USER_LOCAL_DIR"

  if [ "$EP_HDP_VERSION" != "" ]; then
    echo -e `date` "localhost ${icolor}INFO:${nocolor} HDP_VERSION=$EP_HDP_VERSION"
  fi
}
#==========================================================
# Sets basic Hadoop environment variables
#   - EP_JAVA_LIBRARY_PATH
#   - JAVA_LIBJSIG
#   - EP_HADOOP_HOME
#   - EP_JAVA_HOME
#==========================================================
setHadoopInstallVariables()
{
  LOGIC=`hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -setprops | awk '{print $1}' 2> /dev/null`

  eval $LOGIC
  #----------------------------------------------------------
  # Make sure we were able to collect all necessary info
  #----------------------------------------------------------
  if [ "$EP_JAVA_LIBRARY_PATH" == "" ] || [ "$EP_HADOOP_HOME" == "" ] || [ "$EP_JAVA_HOME" == "" ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to determine the basic Hadoop environment variables."
    exit 1
  fi
  #----------------------------------------------------------
  # Resolve Java native library path
  #----------------------------------------------------------
  EP_JAVA_LIBRARY_PATH=`echo -e $EP_JAVA_LIBRARY_PATH | awk -F: '{print $NF}'`

  if [ ! -e $EP_JAVA_LIBRARY_PATH ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Java library path $EP_JAVA_LIBRARY_PATH does not exist."
    exit 1
  fi
  #----------------------------------------------------------
  # Resolve Hadoop home
  #----------------------------------------------------------
  if [ ! -e $EP_HADOOP_HOME ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Hadoop home path $EP_HADOOP_HOME does not exist."
    exit 1
  fi
  #----------------------------------------------------------
  # Resolve Java Home
  #----------------------------------------------------------
  if [ ! -e $EP_JAVA_HOME ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Java home path $EP_JAVA_HOME does not exist."
    exit 1
  fi
  #----------------------------------------------------------
  # Resolve Java libjsig.so library path
  #----------------------------------------------------------
  if [ "$JAVA_LIBJSIG" == "" ]; then
    JAVA_LIBJSIG=`find $EP_JAVA_HOME -follow -type f -name libjsig.so | head -1`

    if [ "$JAVA_LIBJSIG" == "" ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to determine Java library libjsig.so path."
      exit 1
    fi
  fi

  if [ ! -e $JAVA_LIBJSIG ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Java signal library $JAVA_LIBJSIG does not exist."
    exit 1
  fi
  #----------------------------------------------------------
  # Resolve Hadoop Map Reduce Framework
  #----------------------------------------------------------
  if [ "$EP_MAPRED_FRAMEWORK" == "classic" ]; then
    let IS_LINK_HADOOP_LIB=1
  fi
  #----------------------------------------------------------
  # Resolve Hadoop install folders
  #----------------------------------------------------------
  getHCatalogClassPath

  HADOOP_CORE_DIR=$EP_HADOOP_HOME
  HADOOP_CORE_LIB=$HADOOP_CORE_DIR/lib
  HDFS_USER=hdfs;

  if [ $EP_IS_MAPR -eq 1 ]; then
    HADOOP_CORE_LIB=$HADOOP_CORE_DIR/share/hadoop/common/lib
    HDFS_USER=mapr;
  else if [ -e $HADOOP_CORE_DIR/lib ]; then
    HADOOP_CORE_LIB=$HADOOP_CORE_DIR/lib
  else
    HADOOP_CORE_LIB=$HADOOP_CORE_DIR
  fi
  fi
}
#==========================================================
# Make sure the local host is in the list of nodes.
#==========================================================
checkNodesList()
{
  LOCALHOST=`hostname`

  for node in $EP_SERVER_HOSTLIST; do
    if [ "${node%%.*}" == "${LOCALHOST%%.*}" ]; then
      isHostFound=1;
    fi
  done

  if [ ! $isHostFound ]; then
    EP_SERVER_HOSTLIST="$EP_SERVER_HOSTLIST $LOCALHOST"
  fi
}
#==========================================================
# Check if security/license folder is deployed on all nodes
#==========================================================
checkFolderDeployment()
{
  let indx=-1;
  let count=0;
  let serverCount=0;
  folder=$1

  # Look for EP istalled under product folder
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      let serverCount++
      let indx++

      HH[$indx]="${LOGNAME}@$node"
      WW[$indx]=`ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
          if [ -e $folder ]; then
            echo -e \"1\";
          else
            echo -e \"0\";
          fi
      " &`
    fi
  done

  wait

  let errcount=0;

  for i in `seq 0 $indx`; do
    # Check if the value is an interger
    if ! [[ "${WW[$i]}" =~ ^[0-9]+$ ]]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to communicate with ${HH[$i]}. Make sure user ${LOGNAME} exists and its ssh keys are properly configured."
      let errcount++
    else
      let count+=${WW[$i]}
    fi
  done

  if [ $errcount -ne 0 ]; then
    exit 1;
  fi

  return $count
}
#==========================================================
# Check if the EP is installed on current location across cluster.
# Returns count of number of installs at current location in
# cluster with matching # of files to local install.
#==========================================================
checkEPInstallLocation()
{
  let indx=-1;
  let count=0;
  let serverCount=0;

  if [ -e $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ] || [ -h $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Found SAS Embedded Process JAR files linked under $HADOOP_CORE_LIB."
  fi

  if [ -e $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ] || [ -h $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Found SAS Embedded Process shared library linked under $EP_JAVA_LIBRARY_PATH."
  fi
  # Look for JAR files and shared libraries linked unde Hadoop lib folder
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
         if [ -e $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ] || [ -h $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ]; then
           echo -e \`date\` \"$node ${wcolor}WARN:${nocolor} Found SAS Embedded Process JAR files linked under $HADOOP_CORE_LIB.\"
         fi

         if [ -e $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ] || [ -h $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ]; then
           echo -e \`date\` \"$node ${wcolor}WARN:${nocolor} Found SAS Embedded Process shared library linked under $EP_JAVA_LIBRARY_PATH.\"
         fi
      " 2>&1 &
    fi
  done

  numLocalFiles=`find $SAS_EP_HOME -type f | wc -l`

  # Look for EP istalled under product folder
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      let indx++
      let serverCount++

      HH[$indx]="${LOGNAME}@$node"
      numRemoteFiles=`ssh ${SSH_OPTIONS} ${LOGNAME}@$node "find $SAS_EP_HOME -type f 2>/dev/null | wc -l"`

      if [ $numRemoteFiles -eq $numLocalFiles ]; then
        WW[$indx]=1
      else
        WW[$indx]=0
      fi
    fi
  done

  let errcount=0;

  for i in `seq 0 $indx`; do
    # Check if the value is an integer
    if ! [[ "${WW[$i]}" =~ ^[0-9]+$ ]]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to communicate with ${HH[$i]}. Make sure user ${LOGNAME} exists and its ssh keys are properly configured."
      let errcount++
    else
      let count+=${WW[$i]}
    fi
  done

  if [ $errcount -ne 0 ]; then
    exit 1;
  fi

  return $count
}
#==========================================================
# Execute link latest EP JAR file
#==========================================================
executeLinkLatestEPJarFile()
{
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Linking lastest SAS Embedded Process JAR file to $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME}."

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ]; then
      ln -fs $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME} $SAS_EP_JAR_LINK_NAME
    else
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
        echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Linking lastest SAS Embedded Process JAR file to $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME}.\";
        ln -fs $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME} $SAS_EP_JAR_LINK_NAME
      " &
    fi
  done

  wait
}
#==========================================================
# Execute CHECK action
#==========================================================
executeCheckAction()
{
  # Check if EP configuration file exists
  checkLocalConfigFileExistence
  if [ $? -eq 0 ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} SAS Embedded Process configuration file does not exist on local file system under $SAS_EP_LOCAL_CONFIG_FOLDER."
  fi

  checkHDFSConfigFileExistence
  rcl=$?
  if  [ $IS_NOSUDO -eq 0 ] && [ $rcl -eq 0 ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} SAS Embedded Process configuration file does not exist on HDFS $EP_FULL_CONFIG_FILE_PATH."
  fi

  # Validate EP installation on every node that was specified.
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Validating SAS Embedded Process on remote nodes under $SAS_EP_HOME."

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
          if [ -e $SAS_EP_HOME ]; then
            count=\`find $SAS_EP_HOME -type f | wc -l\`
            echo -e \`date\` \"${node} ${green}FOUND${nocolor} \$count files.\";
          else
            echo -e \`date\` \"${node} ${ecolor}NOT FOUND${nocolor}\";
          fi
      " &
    fi
  done

  wait

  checkEPInstallLocation

  let count=$?

  if [ $count -eq 0 ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} No SAS Embedded Process found on remote nodes."
  elif [ $count -eq $serverCount ]; then
    echo -e `date` "localhost ${icolor}INFO:${nocolor} Found SAS Embedded Process installed on this node and $count of $serverCount remote nodes."
  else
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Found SAS Embedded Process installed on this node and $count of $serverCount remote nodes."
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Found inconsistent install on $(($serverCount - $count)) remote nodes."
  fi

}
#==========================================================
# UNINSTALL EMBEDDED PROCESS FOR HADOOP
#==========================================================
removeEPServer()
{
  echo -e `date` "localhost ${icolor}INFO:${nocolor} *******************************************************************************"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Uninstalling SAS Embedded Process for Hadoop."
  echo -e `date` "localhost ${icolor}INFO:${nocolor} *******************************************************************************"

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ] ; then
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} Folders located under $SAS_EP_HOME will not be removed."

      removeLocalEPConfigFile
      removeHDFSEPConfigFile

      if [ -e $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ] || [ -h $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ]; then
        rm -f $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} 2>&1
        echo -e `date` "localhost ${icolor}INFO:${nocolor} Removed $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}."
      fi

      if [ -e $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ] || [ -h $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ]; then
        rm -f $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1
        echo -e `date` "localhost ${icolor}INFO:${nocolor} Removed $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY."
      fi
      #------------------------------------------
      # Removing symbolic link to actual JAR file
      #------------------------------------------
      echo -e `date` "localhost ${icolor}INFO:${nocolor} Removing symbolic link $SAS_EP_JAR_LINK_NAME."
      rm -f $SAS_EP_JAR_LINK_NAME
    else
      echo -e `date` "${node} ${icolor}INFO:${nocolor} Uninstalling SAS Embedded Process for Hadoop."

      ssh ${SSH_OPTIONS} ${LOGNAME}@${node} "
          if [ -e $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ] || [ -h $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ]; then
            rm -f $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} 2>&1
            echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Removed $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}.\";
          fi

          if [ -e $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ] || [ -h $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ]; then
            rm -f $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1
            echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Removed $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY.\";
          fi

          rm -rf $SAS_EP_HOME 2>&1

      "  2>&1 &
    fi
  done
  # Wait on all sub-processes
  wait

  echo -e `date` "localhost ${icolor}INFO:${nocolor} Validating SAS Embedded Process on remote nodes."

  checkEPInstallLocation
  let count=$?
  if [ $count -eq 0 ]; then
    echo -e `date` "localhost ${icolor}INFO:${nocolor} Successfully removed SAS Embedded Process from all $serverCount remote nodes."
  else
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to remove SAS Embedded Process from $count remote nodes."
  fi
}
#==========================================================
# PARALLEL deletion of folder content
#==========================================================
parallelDeleteFolderContent()
{
  folder=$1

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "

          if [ -e ${folder} ]; then
            rm -rf ${folder}/*;
            rc=\$?;
            if [ \$rc -ne 0 ]; then
              echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Failed to remove contents from ${folder}.\";
              exit 1;
            fi;
          fi
        " 2>&1 &
    fi
  done

  wait
}
#==========================================================
# PARALLEL CREATION OF FOLDER
#==========================================================
parallelCreateFolder()
{
  folder=$1

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "

          if [ ! -e ${folder} ]; then
            echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Creating directory ${folder}.\";
            mkdir -p ${folder};
            rc=\$?;
            if [ \$rc -ne 0 ]; then
              echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Failed to create directory ${folder}.\";
              exit 1;
            fi;
          else
            rm -rf ${folder}/*;
            rc=\$?;
            if [ \$rc -ne 0 ]; then
              echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Failed to remove contents from ${folder}.\";
              exit 1;
            fi;
          fi
        " 2>&1 &
    fi
  done

  wait
}
#==========================================================
# PARALLEL DEPLOY A FOLDER
#==========================================================
parallelDeployFolderContents()
{
  let scpcount=0;
  let nodesCount=0;
  folder=$1
  fileName=$2

  if [ "$fileName" == "" ]; then
    fullPath="${folder}/*"
  else
    fullPath="${folder}/${fileName}"
  fi

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      let nodesCount++;

      bash -c "scp -r $SCP_OPTIONS ${fullPath} ${LOGNAME}@$node:${folder} 2>&1;
                 let rc=\$?;
                 if [ \$rc -ne 0 ]; then
                   echo -e -e \`date\` \"localhost ${ecolor}ERROR:${nocolor} Unable to deploy $folder to $node.${nocolor}\";
                 fi;
               " 2>&1 &

      let scpcount=(`jobs -p | wc -l`)-1

      if [ $scpcount -ge $MAX_PARALLEL_SCP ]; then
        while [ true ]; do
          sleep 0.5;
          let scpcount=(`jobs -p | wc -l`)-1
          if [ $scpcount -lt $MAX_PARALLEL_SCP ]; then
            break;
          fi;
        done;
      fi;
    fi
  done

  wait
}
#==========================================================
# PARALLEL COPY OF SAS EMBEDDED PROCESS
#==========================================================
parallelCreateSASROOT()
{
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ]; then
      chmod -R 0755 $SAS_EP_HOME 2>&1

      if [ $IS_LINK_HADOOP_LIB -eq 1 ]; then
        echo -e `date` "localhost ${icolor}INFO:${nocolor} Linking $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}."
        ln -fs $SAS_EP_JAR_LINK_NAME $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} 2>&1
        echo -e `date` "localhost ${icolor}INFO:${nocolor} Linking $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY."
        ln -fs $SAS_EP_SASEXE/$SAS_EP_JNI_LIBRARY $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1
      fi
    else
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "

          if [ -e $SAS_EP_HOME ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} SAS Embedded Process is already installed on current location.\";
            exit 1;
          fi

          if [ ! -e ${SAS_EP_HOME} ]; then
            echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Creating directory ${SAS_EP_HOME}.\";
            mkdir -p ${SAS_EP_HOME};
            rc=\$?;
            if [ \$rc -ne 0 ]; then
              echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Failed to create directory ${SAS_EP_HOME}.\";
              exit 1;
            fi;
          fi
          # Make sure SAS_EP_HOME is not populated
          count=\`ls -1 ${SAS_EP_HOME} | wc -l\`

          if [ "\$count" -gt "0" ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Unable to install SAS Embedded Process in a folder that is already populated. ${SAS_EP_HOME}.\";
            exit 1;
          fi
        " 2>&1 &
    fi
  done

  wait
}
#==========================================================
# PARALLEL COPY OF SAS EMBEDDED PROCESS
#==========================================================
syncInstallDir()
{
  let rsynccount=0;
  let nodesCount=0;

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      echo -e `date` "localhost ${icolor}INFO:${nocolor} Syncing local install with node $node."
      let nodesCount++;

      bash -c "  rsync $RSYNC_OPTIONS ${SAS_EP_HOME} ${LOGNAME}@$node:${SAS_EP_INSTALL_ROOT} 2>&1;
                 let rc=\$?;
                 if [ \$rc -ne 0 ]; then
                   echo -e -e \`date\` \"localhost ${ecolor}ERROR:${nocolor} Unable to to sync with $node.${nocolor}\";
                 fi;
               " 2>&1 &

      let rsynccount=(`jobs -p | wc -l`)-1

      if [ $rsynccount -ge $MAX_PARALLEL_RSYNC ]; then
        while [ true ]; do
          sleep 0.5;
          let rsynccount=(`jobs -p | wc -l`)-1
          if [ $rsynccount -lt $MAX_PARALLEL_RSYNC ]; then
            break;
          fi;
        done;
      fi;
    fi
  done

  wait
}
#==========================================================
# Prompt. Returns the response in userInput
#==========================================================
promptYesNo()
{
  userInput=""

  until [ "$userInput" == "$2" ] || [ "$userInput" == "$3" ]; do
    echo " "
    read -p "${1} " userInput
    userInput=`echo -e "$userInput"`
    userInput=`echo $userInput | awk '{print toupper($0)}'`
  done
}
#==========================================================
# Remove license files from remote nodes
#==========================================================
removeLicense()
{
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Removing license file."

  parallelDeleteFolderContent ${SAS_EP_LICENSE_INSTALL_DIR}
  #rm -rf ${SAS_EP_LICENSE_INSTALL_DIR}/*
}
#==========================================================
# Deploy license file to remote nodes
#==========================================================
deployLicense()
{
  #==========================================================
  # Make sure setinit file exists
  #==========================================================
  isValid=`validateFileLocation ${SAS_EP_LICENSE_INSTALL_DIR}/${SAS_EP_LICENSE_SETINIT_FILE}`
  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi
  #==========================================================
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Deploying license file."
  # Check if EP is installed on current location
  checkEPInstallLocation
  let count=$?
  if [ $count == 0 ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} SAS Embedded Process must be installed to perform license deployment."
    exit 1
  fi

  # Check if license file is already deployed
  checkFolderDeployment ${SAS_EP_LICENSE_INSTALL_DIR}/$SAS_EP_LICENSE_SETINIT_FILE
  let count=$?
  if [ $count -gt 0 ] && [ $IS_FORCE_OVERWRITE -eq 0 ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} License file is already deployed to remote nodes."
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} To overwrite license file without prompt, use -force option."

    promptYesNo "--> Do you want to overwrite license files? [y/n]? " Y N

    if [ "$userInput" == "N" ]; then
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} License file was not deployed."
      exit 1
    fi
  fi
  # Create license folder
  parallelCreateFolder ${SAS_EP_LICENSE_INSTALL_DIR}
  # Copy license file
  parallelDeployFolderContents ${SAS_EP_LICENSE_INSTALL_DIR} $SAS_EP_LICENSE_SETINIT_FILE

  echo -e `date` "localhost ${icolor}INFO:${nocolor} License deployment is finished."
}
#==========================================================
# Remove security settings from remote nodes
#==========================================================
resetSecurity()
{
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Restoring security configuration."

  rm -rf ${SAS_EP_SECURITY_INSTALL_DIR}/*

  isValid=`validateFileLocation ${SAS_EP_MISC_DEPLOYMENT}/${SAS_EP_SECURITY_CONFIG_FILE}`
  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi

  cp $SAS_EP_MISC_DEPLOYMENT/$SAS_EP_SECURITY_CONFIG_FILE ${SAS_EP_SECURITY_INSTALL_DIR}
}
#==========================================================
# ADD CAS SECURITTY
#==========================================================
deploySecurity()
{
  #==========================================================
  # Make sure security configuration file exists
  #==========================================================
  isValid=`validateFileLocation ${SAS_EP_SECURITY_CONFIG_FILE_VARIABLE}`
  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi
  #==========================================================
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Deploying security settings."
  # Check if EP is installed on current location
  checkEPInstallLocation
  let count=$?
  if [ $count == 0 ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} SAS Embedded Process must be installed to perform security deployment."
    exit 1
  fi

  # Check if EP security is already deployed
  checkFolderDeployment $SAS_EP_SECURITY_INSTALL_DIR
  let count=$?
  if [ $count -gt 0 ] && [ $IS_FORCE_OVERWRITE -eq 0 ]; then
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} Security is already deployed to remote nodes."
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} To overwrite configuration settings without prompt, use -force option."

    promptYesNo "--> Do you want to overwrite security configuration settings? [y/n]? " Y N

    if [ "$userInput" == "N" ]; then
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} Security configuration settings were not deployed."
      exit 1
    fi
  fi
  # Create CAS Security folder on all nodes
  parallelCreateFolder ${SAS_EP_SECURITY_INSTALL_DIR}
  # Copy CAS Security files to all nodes
  parallelDeployFolderContents ${SAS_EP_SECURITY_INSTALL_DIR}

  echo -e `date` "localhost ${icolor}INFO:${nocolor} Security deployment is finished."
}
#==========================================================
# INSTALL A NEW EMBEDDED PROCESS FOR HADOOP
#==========================================================
addEPServer()
{
  echo -e `date` "localhost ${icolor}INFO:${nocolor} *******************************************************************************"
  echo -e `date` "localhost ${icolor}INFO:${nocolor} Installing SAS Embedded Process for Hadoop."
  echo -e `date` "localhost ${icolor}INFO:${nocolor} *******************************************************************************"
  # Check if EP is already installed on current location
  checkEPInstallLocation
  let count=$?

  if [ "$ACTION" == "ADD" ]; then
    if [ $count != 0 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} SAS Embedded Process is already installed on $count of $serverCount specified remote nodes."
      exit 1
    fi

    let CREATE_CONF_VOTES=0

    checkLocalConfigFileExistence
    if [ $? -eq 1 ]; then
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} Local configuration file $SAS_EP_LOCAL_CONFIG_FILE exists and will not be overwritten."
    else
      createLocalConfigFolder
      let CREATE_CONF_VOTES++
    fi

    checkHDFSConfigFileExistence
    if [ $? -eq 1 ]; then
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} Configuration file $TEMP_CONFNAME exists and will not be overwritten."
    else
      let CREATE_CONF_VOTES++
    fi

    if [ $CREATE_CONF_VOTES -eq 2 ]; then
      generateEPConfigFile
    fi
    #------------------------------------------
    # Create a symbolic link to actual JAR file
    #------------------------------------------
    if [ "$ACTION" == "ADD" ]; then
      ln -fs $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME} $SAS_EP_JAR_LINK_NAME
    fi

    parallelCreateSASROOT
  fi

  # Sync install dir to all nodes using rsync
  syncInstallDir

  # Link JAR to hadoop core lib on all nodes
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
          cd ${SAS_EP_INSTALL_ROOT};
          #------------------------------------------
          # Create a symbolic link in Hadoop core lib
          #------------------------------------------
          if [ $IS_LINK_HADOOP_LIB -eq 1 ]; then
            ln -fs $SAS_EP_JAR_LINK_NAME $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} 2>&1;
            echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Linking $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY.\";
            ln -fs $SAS_EP_SASEXE/$SAS_EP_JNI_LIBRARY $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1;
          fi
          chmod -R 0755 $SAS_EP_HOME 2>&1;
        " 2>&1 &
      ##======================
      ## End of ssh invokation
      ##======================
    fi
  done

  # Wait on all sub-processes
  wait

  if [ "$ACTION" == "ADD" ]; then
    echo -e `date` "localhost ${icolor}INFO:${nocolor} Validating SAS Embedded Process on remote nodes."

    checkEPInstallLocation
    let count=$?
    if [ $count -eq $serverCount ]; then
      echo -e `date` "localhost ${icolor}INFO:${nocolor} Successfully added SAS Embedded Process to all $serverCount remote nodes."
    else
      let t=$serverCount-$count
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to add SAS Embedded Process to $t of $serverCount remote nodes."
    fi
  else
    echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS Embedded Process administrative script is finished."
  fi
}
#==========================================================
# Create EP JAR files links under Hadoop lib folder
#==========================================================
createEPJARLinks()
{
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ]; then
      echo -e `date` "localhost ${icolor}INFO:${nocolor} Linking $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}."
      ln -fs $SAS_EP_JAR_LINK_NAME $HADOOP_CORE_LIB/$SAS_EP_JAR_LINK_BASENAME 2>&1

      if [ $? -ne 0 ]; then
        echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to link $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}."
      fi

      echo -e `date` "localhost ${icolor}INFO:${nocolor} Linking $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY."
      ln -fs $SAS_EP_SASEXE/$SAS_EP_JNI_LIBRARY $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1

      if [ $? -ne 0 ]; then
        echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to link $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY."
      fi
    else
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
          if [ ! -e $SAS_EP_HOME ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} SAS Embedded Process is not installed on current location.\";
            exit 1;
          fi

          echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Linking $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}.\";
          ln -fs $SAS_EP_JAR_LINK_NAME $HADOOP_CORE_LIB/$SAS_EP_JAR_LINK_BASENAME 2>&1

          if [ \$? -ne 0 ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Unable to link $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}.\"
          fi

          echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Linking $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY.\";
          ln -fs $SAS_EP_SASEXE/$SAS_EP_JNI_LIBRARY $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1;

          if [ \$? -ne 0 ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Unable to link $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY.\"
          fi
      " 2>&1 &
    fi
  done
  # Wait on all sub-processes
  wait
}

#==========================================================
# Create a link to latest EP JAR under SASEPHome jars folder
#==========================================================
linkSASEPJAROnly()
{
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ]; then
      echo -e `date` "localhost ${icolor}INFO:${nocolor} Linking $SAS_EP_JAR_LINK_NAME to $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME}."
      #------------------------------------------
      # Create a symbolic link to actual JAR file
      #------------------------------------------
      ln -fs $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME} $SAS_EP_JAR_LINK_NAME 2>&1

      if [ $? -ne 0 ]; then
        echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to link $SAS_EP_JAR_LINK_NAME to $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME}."
      fi
    else
      ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
          if [ ! -e $SAS_EP_HOME ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} SAS Embedded Process is not installed on current location.\";
            exit 1;
          fi

          echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Linking $SAS_EP_JAR_LINK_NAME to $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME}.\";
          ln -fs $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME} $SAS_EP_JAR_LINK_NAME 2>&1

          if [ \$? -ne 0 ]; then
            echo -e \`date\` \"${node} ${ecolor}ERROR:${nocolor} Unable to link $SAS_EP_JAR_LINK_NAME to $SAS_EP_JARS/${SAS_EP_ACTUAL_JAR_BASENAME}.\"
          fi
      " 2>&1 &
    fi
  done
 # Wait on all sub-processes
  wait
}

#==========================================================
# Remove EP JAR files links from Hadoop lib folder
#==========================================================
removeEPJARLinks()
{
  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" == "$REMOTE_HOST" ] ; then

      if [ -e $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ] || [ -h $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ]; then
        rm -f $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} 2>&1
        echo -e `date` "localhost ${icolor}INFO:${nocolor} Removed $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}."
      fi

      if [ -e $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ] || [ -h $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ]; then
        rm -f $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1
        echo -e `date` "localhost ${icolor}INFO:${nocolor} Removed $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY."
      fi
    else
      ssh ${SSH_OPTIONS} ${LOGNAME}@${node} "
       if [ -e $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ] || [ -h $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} ]; then
         rm -f $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME} 2>&1
         echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Removed $HADOOP_CORE_LIB/${SAS_EP_JAR_LINK_BASENAME}.\";
       fi

       if [ -e $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ] || [ -h $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY ]; then
         rm -f $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY 2>&1
         echo -e \`date\` \"${node} ${icolor}INFO:${nocolor} Removed $EP_JAVA_LIBRARY_PATH/$SAS_EP_JNI_LIBRARY.\";
       fi
      " 2>&1 &
    fi
  done
  # Wait on all sub-processes
  wait
}
#==========================================================
# Check that rsync utility is available on all remote nodes
# before continuing
#==========================================================
checkRSyncInstalled()
{
  let NO_RSYNC_COUNT=0

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      HAS_RSYNC=`ssh ${SSH_OPTIONS} ${LOGNAME}@$node "
        if [ -x \"$(command -v rsync)\" ]; then
          echo -e \"1\";
        else
          echo -e \"0\";
        fi
      " &`
    fi

    if [ $HAS_RSYNC -ne 1 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to locate rsync utility on system."
      let NO_RSYNC_COUNT++
    fi
  done

  wait

  if [ $NO_RSYNC_COUNT -ne 0 ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to locate rsync utility on $NO_RSYNC_COUNT nodes."
    exit 1
  fi
}
#==========================================================
# Ensure that there are no issues with SSH known_hosts file
# for provided host list
#==========================================================
checkKnownHostsFile()
{
  let HOST_ISSUE_COUNT=0

  for node in $EP_SERVER_HOSTLIST; do
    REMOTE_HOST=${node%%.*}

    if [ "$LOCAL_HOST" != "$REMOTE_HOST" ]; then
      CAN_CONNECT=`ssh-keygen -F $node` 2> /dev/null

      if [ "$CAN_CONNECT" == "" ]; then
        echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Node $node not found in SSH known_hosts file."
        let HOST_ISSUE_COUNT++
      fi
    fi
  done

  if [ $HOST_ISSUE_COUNT -ne 0 ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} To disable strict host checking, use the -nohostcheck option."
    echo -e `date` "localhost ${wcolor}WARN:${nocolor} The -nohostcheck option should be used with caution."
    exit 1
  fi
}
#==========================================================
# Check for duplicate actions in command line
#==========================================================
checkDuplicateActionError()
{
  ACT1=$1
  ACT2=$2

  if [ "$ACTION" ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Option $ACT1 cannot be used in conjunction with any other action option: [$ACT2]."
    exit 1
  fi
}
#==========================================================
# Check for duplicate actions in command line
#==========================================================
checkActionMissingValueError()
{
  ACT1=$1
  ACT2=$2
  #------------------------------------------------
  # Checks if the value starts with a -
  #------------------------------------------------
  let i=`echo $ACT1 | awk '{print index($1, "-")}'`

  if [ "$ACT1" == "//" ] || [ $i == 2 ]; then
    if [ "$ACT2" != "-genconfig" ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Option $ACT2 is missing a value."
      exit 1
    fi

    return 1
  fi
}
#==========================================================
# Deploy license options
#==========================================================
setLicense()
{
  #==========================================================
  # Make sure license directory exists
  #==========================================================
  isValid=`validateDirectoryLocation ${SAS_EP_LICENSE_INSTALL_DIR}`
  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi
  #==========================================================
  case $1 in
    deploy )
      deployLicense
      ;;
    remove )
      let IS_FORCE_OVERWRITE=1
      removeLicense
      echo -e `date` "localhost ${icolor}INFO:${nocolor} License has been removed."
      ;;
    * )
      echo -e ""
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} \"${1}\" is an invalid license option."
      exit 1
      ;;
  esac
}
#==========================================================
# Set CAS driver security options
#==========================================================
setSecurity()
{
  #==========================================================
  # Make sure security directory exists
  #==========================================================
  isValid=`validateDirectoryLocation ${SAS_EP_SECURITY_INSTALL_DIR}`
  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi
  #==========================================================
  case $1 in
    deploy )
      deploySecurity
      ;;
    reset )
      let IS_FORCE_OVERWRITE=1
      resetSecurity
      deploySecurity
      echo -e `date` "localhost ${icolor}INFO:${nocolor} Security setting has been restored."
      ;;
    * )
      echo -e ""
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} \"${1}\" is an invalid security option."
      exit 1
      ;;
  esac
}
#==========================================================
# OUTER BLOCK
#==========================================================
echo -e `date` "localhost ${icolor}INFO:${nocolor} Initializing script environment."

# Check script prerequisites
if ! [ -x "$(command -v rsync)" ]; then
  echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to locate rsync utility on system."
  exit 1
fi

# Initialize variables
export HADOOP_USER_CLASSPATH_FIRST=yes
export HADOOP_CLASSPATH=${SAS_EP_JAR_FILE}
SAS_EP_ACTUAL_JAR_BASENAME=`basename ${SAS_EP_JAR_FILE}`
# Hadoop commands
HADOOP_CMD_RM="-rm"
HADOOP_CMD_RMR="-rm -r"
HADOOP_CMD_MKDIR="-mkdir -p"
# Call into Admin Java class to set Hadoop variables
setHadoopInstallVariables

# Check if the user running this script has passwordless sudo privileges to user hdfs
sudo -v -n -u $HDFS_USER > /dev/null 2>&1
let IS_NOSUDO=$?

if [ $IS_NOSUDO == 1 ]; then
  echo -e `date` "localhost ${icolor}INFO:${nocolor} User ${LOGNAME} has no passwordless sudo privileges to user $HDFS_USER."
fi;
## ===============================================================
## How are we going to su
## ===============================================================
RUNASHDFSUSER="sudo -n -u $HDFS_USER /bin/bash -c "
#==========================================================
# Parse input parameters
#==========================================================
cd $SAS_EP_BIN
let sequence=0
let IS_NOHOSTCHECK=0

while [ "$1" != "" ]; do
  let sequence++
  case $1 in
    -x )
      shift 1
      echo -e `date` "localhost ${wcolor}WARN:${nocolor} Option -x is no longer supported and will have no effect."
      ;;
    -security )
      checkDuplicateActionError $1 $ACTION
      ACTION="SECURITY"
      SECOPTIONS=`trimSpaces $2`
      shift 2
      checkActionMissingValueError "/${SECOPTIONS}/" -security
      ;;
    -license )
      checkDuplicateActionError $1 $ACTION
      ACTION="LICENSE"
      SECOPTIONS=`trimSpaces $2`
      shift 2
      checkActionMissingValueError "/${SECOPTIONS}/" -license
      ;;
    -add )
      checkDuplicateActionError $1 $ACTION
      ACTION="ADD"
      shift 1
      ;;
    -sync )
      checkDuplicateActionError $1 $ACTION
      ACTION="SYNC"
      shift 1
      ;;
    -remove )
      checkDuplicateActionError $1 $ACTION
      ACTION="REMOVE"
      shift 1
      ;;
    -hostfile )
      EP_HOST_FILE=`replaceSpaces $2`
      EP_HOST_FILE=`trimSpaces $EP_HOST_FILE`
      shift 2
      checkActionMissingValueError "/${EP_HOST_FILE}/" -hostfile
      let IS_HOSTOPTION=1
      ;;
    -host )
      EP_SERVER_HOSTLIST=`replaceCommasBySpaces $2`
      shift 2
      checkActionMissingValueError "/${EP_SERVER_HOSTLIST}/" -host
      let IS_HOSTOPTION=1
      ;;
    -hdfsuser )
      HDFS_USER=`replaceSpaces $2`
      HDFS_USER=`trimSpaces $HDFS_USER`
      shift 2
      checkActionMissingValueError "/${HDFS_USER}/" -hdfsuser
      ;;
    -nodelist )
      checkDuplicateActionError $1 $ACTION
      ACTION="NODELIST"
      shift 1
      ;;
    -yarnrm )
      YARN_RESOURCE_MANAGER=`replaceSpaces $2`
      YARN_RESOURCE_MANAGER=`trimSpaces $YARN_RESOURCE_MANAGER`
      shift 2
      checkActionMissingValueError "/${YARN_RESOURCE_MANAGER}/" -yarnrm
      ;;
    -yarnnodes )
      checkDuplicateActionError $1 $ACTION
      ACTION="YARNNODELIST"
      shift 1
      ;;
    -genconfig )
      checkDuplicateActionError $1 $ACTION
      ACTION="GENCONFIG"
      if [ $IS_NOSUDO -eq 0 ]; then
        checkActionMissingValueError "/${2}/" -genconfig

        if [ $? -eq 1 ]; then
          EP_FULL_CONFIG_FILE_PATH=$SAS_EP_DEFAULT_CONFIG_FILE_NAME
          shift 1
        else
          EP_FULL_CONFIG_FILE_PATH=$2
          shift 2
        fi
      else
        shift 1
      fi
      ;;
    -force )
      let IS_FORCE_OVERWRITE=1
      shift 1
      ;;
    -linksasepjaronly )
      checkDuplicateActionError $1 $ACTION
      ACTION="LINKSASEPJARONLY"
      shift 1
      ;;
    -linklib )
      checkDuplicateActionError $1 $ACTION
      ACTION="LINKLIB"
      shift 1
      ;;
    -unlinklib )
      checkDuplicateActionError $1 $ACTION
      ACTION="UNLINKLIB"
      shift 1
      ;;
    -hadoopversion )
      checkDuplicateActionError $1 $ACTION
      ACTION="HADOOPVERSION"
      shift 1;
      ;;
    -link )
      let IS_LINK_HADOOP_LIB=1
      shift 1
      ;;
    -version )
      checkDuplicateActionError $1 $ACTION
      ACTION="VERSION"
      shift 1;
      ;;
    -check )
      checkDuplicateActionError $1 $ACTION
      ACTION="CHECK"
      shift 1;
      ;;
    -maxparallel )
      MAX_PARALLEL_SCP=$2
      MAX_PARALLEL_RSYNC=$2
      shift 2
      checkActionMissingValueError "/${MAX_PARALLEL_SCP}/" -maxcp
      # Check if the value is an integer
      if ! [[ "$MAX_PARALLEL_SCP" =~ ^[0-9]+$ ]]; then
        echo -e `date` "localhost ${ecolor}ERROR:${nocolor} The value specified in -maxparallel is not valid. Please enter a number greater than 0."
        exit 1
      fi
      # Check if the value is greater that 0
      if [ $MAX_PARALLEL_SCP -le 0 ]; then
        echo -e `date` "localhost ${ecolor}ERROR:${nocolor} The value specified in -maxparallel must be greater than 1."
        exit 1
      fi
      ;;
    -nohostcheck )
      SCP_OPTIONS="$SCP_OPTIONS -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
      SSH_OPTIONS="$SSH_OPTIONS -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
      RSYNC_OPTIONS="$RSYNC_OPTIONS -e \"ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null\""
      let IS_NOHOSTCHECK=1
      shift 1
      ;;
    -env )
      checkDuplicateActionError $1 $ACTION
      ACTION="ENV"
      shift 1;
      ;;
    -hadoopenv )
      checkDuplicateActionError $1 $ACTION
      ACTION="HADOOPENV"
      shift 1;
      ;;
    -linklatest )
      checkDuplicateActionError $1 $ACTION
      ACTION="LINKLATEST"
      shift 1;
      ;;
    -h|-help )
      printSyntax "${THIS_PROGRAM}"
      ;;
    * )
      echo -e ""
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} \"${1}\" is an invalid option. Enter -h or -help for help."
      exit 1
      ;;
  esac
done

#==========================================================
# PERFORM IMMEDIATE ACTION AND EXIT
#==========================================================
case $ACTION in
  HADOOPVERSION )
    hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -version
    exit 0
    ;;

  VERSION )
    echo -e `date` "localhost ${icolor}INFO:${nocolor} SAS Embedded Process for Hadoop version info:"
    echo -e `date` "localhost ${icolor}INFO:${nocolor} . Major          : $SAS_EP_CONFIG_VERSION_MAJOR"
    echo -e `date` "localhost ${icolor}INFO:${nocolor} . Minor          : $SAS_EP_CONFIG_VERSION_MINOR"
    echo -e `date` "localhost ${icolor}INFO:${nocolor} . Delta          : $SAS_EP_CONFIG_VERSION_DELTA"
    echo -e `date` "localhost ${icolor}INFO:${nocolor} . Implementation : $SAS_EP_CONFIG_VERSION_IMPLEMENTATION"
    exit 0;
    ;;

  ENV )
    echo -e `date` "localhost ${icolor}INFO:${nocolor} =================================================="
    echo -e `date` "localhost ${icolor}INFO:${nocolor}        INSTALL SCRIPT ENVIRONMENT VARIABLES"
    echo -e `date` "localhost ${icolor}INFO:${nocolor} =================================================="
    dumpEnvironment
    echo -e `date` "localhost ${icolor}INFO:${nocolor} =================================================="
    exit 0
    ;;

  HADOOPENV )
    hadoop ${DFS_ADMIN_UTIL_CLASSNAME} -hadoopenv
    exit 0
    ;;

  NODELIST )
    hdpnodes=`getDataNodesList`
    RC=$?
    if [ $RC -ne 0 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} $hdpnodes"
      exit 1
    fi

    echo -e `date` "localhost ${icolor}INFO:${nocolor} List of HDFS Data Nodes:"
    for each in $hdpnodes; do
      echo -e `date` "localhost ${icolor}INFO:${nocolor}   . $each"
    done

    exit 0
    ;;

  YARNNODELIST )
    hdpnodes=`getYarnNodesList`
    RC=$?
    if [ $RC -ne 0 ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} $hdpnodes"
      exit 1
    fi

    echo -e `date` "localhost ${icolor}INFO:${nocolor} List of YARN Node Manager nodes:"
    for each in $hdpnodes; do
      echo -e `date` "localhost ${icolor}INFO:${nocolor}   . $each"
    done

    exit 0
    ;;

  * )
    ;;
esac
#==========================================================
# CHECK OPTIONS
#==========================================================
EP_CONFIG_FILE_XML=`basename ${EP_FULL_CONFIG_FILE_PATH}`
HDFS_CONFIG_FOLDER=`dirname ${EP_FULL_CONFIG_FILE_PATH}`

if [ "$ACTION" == "" ]; then
  echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Required option is missing."
  printSyntax "${THIS_PROGRAM}"
  exit 1
fi
#==========================================================
# Check -force option
#==========================================================
if [ $IS_FORCE_OVERWRITE -eq 1 ] && [ "$ACTION" != "GENCONFIG" ] && [ "$ACTION" != "SECURITY" ] && [ "$ACTION" != "LICENSE" ]; then
   axtion=`echo ${ACTION} | awk '{print tolower($1)}'`
   echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Option -force cannot be used in conjunction with action option -$axtion."
   exit 1
fi

#==========================================================
if [ "$ACTION" == "ADD" ] && [ "$HDFS_USER" == "" ]; then
  echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Option -hdfsuser is required."
  exit 1
fi

#==========================================================
if [ "$ACTION" == "ADD" ]; then
  # Make sure the specified hdfs user exists
  if [ "$HDFS_USER" != "" ]; then
    isValidUser=`isUserExist2 $HDFS_USER`

    if [ "${isValidUser}" != "y" ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} User [${HDFS_USER}] does not exist. Use -hdfsuser <userName> option to specify the Hadoop FS user name."
      exit 1
    fi
  fi
fi
#==========================================================
if [ "$ACTION" == "ADD" ] || [ "$ACTION" == "REMOVE" ]; then
  isValid=`validateDirectoryLocation ${HADOOP_CORE_LIB}`

  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${isValid}"
    exit 1
    fi
fi
#==========================================================
# Populate EP_SERVER_HOSTLIST variable
#==========================================================
if [ "${EP_SERVER_HOSTLIST}" != "" ] && [ "${EP_HOST_FILE}" != "" ]; then
   echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Options -hostfile and -host are mutually exclusive."
   exit 1
fi
#----------------------------------------------------------------------------
# Resolve the host list. If user does not specify the list of hosts, we will
# get it from the cluster.
#----------------------------------------------------------------------------
if [ "$ACTION" == "ADD" ]        ||
   [ "$ACTION" == "SYNC" ]       ||
   [ "$ACTION" == "REMOVE" ]     ||
   [ "$ACTION" == "LINKLATEST" ] ||
   [ "$ACTION" == "CHECK" ]      ||
   [ "$ACTION" == "SECURITY" ]   ||
   [ "$ACTION" == "LICENSE" ]    ||
   [ "$ACTION" == "LINKLIB" ]    ||
   [ "$ACTION" == "UNLINKLIB" ]  ||
   [ "$ACTION" == "LINKSASEPJARONLY" ]; then

  if [ "$EP_SERVER_HOSTLIST" == "" ] &&
     [ "$EP_HOST_FILE" == "" ]       &&
     [ "$SAS_EP_HOSTS" == "" ]       &&
     [ "$SAS_EP_HOSTS_FILE" == "" ]; then
    EP_SERVER_HOSTLIST=`getYarnNodesList`
    RC=$?

    if [ "$EP_SERVER_HOSTLIST" == "" ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} Unable to retrieve a list of YARN NodeManager nodes. Use -host or -hostfile option."
      exit 1
    fi

    if [ $RC -ne 0 ];then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} $EP_SERVER_HOSTLIST"
      EP_SERVER_HOSTLIST=""
    else
      checkNodesList
    fi
    #----------------------------------------------------------------------------
    # If the list of nodes is still not found, we will have to throw an error
    # and ask the user to specify it.
    #----------------------------------------------------------------------------
    if [ "$EP_SERVER_HOSTLIST" == "" ] && [ "$EP_HOST_FILE" == "" ] && [ "$SAS_EP_HOSTS" == "" ] && [ "$SAS_EP_HOSTS_FILE" == "" ]; then
      echo -e `date` "localhost ${ecolor}ERROR:${nocolor} One of the following two options must be specified: -hostfile or -host."
      exit 1
    fi
  fi
fi

if [ "${EP_SERVER_HOSTLIST}" == "" ] && [ "${EP_HOST_FILE}" == "" ] && [ "${SAS_EP_HOSTS_FILE}" != "" ]; then
  EP_HOST_FILE=${SAS_EP_HOSTS_FILE}
fi

if [ "${EP_HOST_FILE}" != "" ]; then
  # make sure the specified host list file is valid
  isValid=`validateFileLocation ${EP_HOST_FILE}`

  if [ "${isValid}" != ""  ]; then
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} ${isValid}"
    exit 1
  fi

  # Populate EP_SERVER_HOSTLIST variable with the list of hosts from file
  EP_SERVER_HOSTLIST=`cat ${EP_HOST_FILE} | sed  "s/#.*$//;/^$/d"`
fi

# If nothing was specified in the hosts or hosts list, we will use SAS_EP_HOSTS
if [ "${EP_SERVER_HOSTLIST}" == "" ]; then
  EP_SERVER_HOSTLIST=`trimSpaces ${SAS_EP_HOSTS}`
fi

if [ $IS_NOHOSTCHECK -eq 0 ]; then
  checkKnownHostsFile
fi

checkRSyncInstalled
#==========================================================
# PERFORM NON IMMEDIATE ACTION
#==========================================================
case $ACTION in
  SECURITY )
    setSecurity $SECOPTIONS
    ;;
  LICENSE )
    setLicense $SECOPTIONS
    ;;
  LINKLATEST )
    executeLinkLatestEPJarFile
    exit
    ;;
  CHECK )
    executeCheckAction
    exit
    ;;
  GENCONFIG )
    generateEPConfigFile
    ;;
  ADD )
    addEPServer
    ;;
  SYNC )
    syncInstallDir
    ;;
  REMOVE )
    removeEPServer
    ;;
  LINKSASEPJARONLY )
    echo -e `date` "${node} ${icolor}INFO:${nocolor} Creating links..."
    linkSASEPJAROnly
    ;;
  LINKLIB )
    echo -e `date` "${node} ${icolor}INFO:${nocolor} Creating links..."
    createEPJARLinks
    ;;
  UNLINKLIB )
    echo -e `date` "${node} ${icolor}INFO:${nocolor} Removing links..."
    removeEPJARLinks
    ;;
  * )
    echo -e ""
    echo -e `date` "localhost ${ecolor}ERROR:${nocolor} \"${ACTION}\" is an invalid action. Enter -h or -help for help."
    exit 1
    ;;
esac
#==========================================================
exit 0
